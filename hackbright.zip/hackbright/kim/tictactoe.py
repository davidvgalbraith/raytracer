import random

def print_instructions():
    instructions = "Hello there! Please choose from the following options: rock, paper or scissors. RULES OF THE GAME: type in either 'rock', 'paper', or 'scissors.' The AI will select a random option. Rock beats scissors. Scissors beats paper. Paper beats rock. Good luck!"

    print instructions

def user_choice():
    print "Press R for Rock"
    print "Press P for Paper"
    print "Press S for Scissors"


    user = raw_input("What do you want to choose?").lower()

    if user == "r":
        return "Rock"
    if user == "p":
        return "Paper"
    if user == "s":
        return "Scissors"

    else:
        print "Please pick a valid entry"

    return user_choice()

def AI_random():
    options = ["rock","paper","scissors"]
    AI_random = random.randint(0,2)
    return options[AI_random]

def comparison(user_choice, AI_random):
    print "TEST: user choice is", user_choice, "AI random is", AI_random
    if user_choice == AI_random:
        return "Tie"
    if user_choice == "Rock" and AI_random == "Paper":
        return "Computer Wins"
    if user_choice == "Paper" and AI_random == "Scissors":
        return "Computer Wins"
    if user_choice == "Scissors" and AI_random == "Rock":
        return "Computer Wins"
    else:
        print "User wins"


while True:
    print_instructions()
    human_choice = user_choice()
    computer_choice =  AI_random()

    print "You chose", human_choice
    print "The computer chose", computer_choice

    result = comparison(human_choice, computer_choice)

    if result == "Tie":
        print "Tie game"
    elif result == "Computer Wins":
        print "AI wins!"
    elif result == "User Wins":
        print "You won!"
