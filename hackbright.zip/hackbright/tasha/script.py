######### OPENING SCENE #########

def read_prompt():
    """Enables pacing of dialogue of game."""
    raw_input("         Press Enter to continue ... ")

def opening_scene():
    """Opening dialogue."""

    print """
            It is a cold December morning in Terryall, Colorado.
            The trees are naked. The air is crisp. You can see your breath with every exhale.
            In a desperate attempt to ward off the cold, you stuff your hands in your jacket pocket. Your phone vibrates.
            """
    read_prompt()
    print """
            It's a text from your friend Thomas.

            >> meet me by the lake
         """
    read_prompt()

######### SECOND SCENE #########

def second_scene():
    """Displays scene after results of first dialogue option."""

    print """
            You and Thomas have never been that close.
            He's, ah, what most would call 'a bit of a loner'.
            That being said, you're pretty relieved to hear from him.
    """
    read_prompt()
    print """
            You throw on a coat, grab your mittens, pull on a hat, and lace up your boots.
            Tempertures can get as low as 10 degrees out here. You're not taking any chances.
    """

######### THIRD SCENE #########

def third_scene():
    """Displays scene after results of second dialogue option."""

    print """
            You ask him what's new.
    """
    read_prompt()
    print """
            Thomas' nose crinkles. It might just be the cold but his eyes look a little red.
            "Let's take a lap around the lake."
    """
    read_prompt()
    print """
            Politely, you oblige him. While you walk the edge of the lake, Thomas can't seem to stop fidgeting.
            You know him well enough that he'll tell you what's wrong in due time.
    """
    read_prompt()
    print """
            "My dad's in town for the holidays."
    """
    read_prompt()
    print """
            You walk two, three steps ahead of Thomas before realizing that he's stopped in his tracks.
    """
    read_prompt()
    print """
            "He wants to see us. Me and my mom."
            Thomas lifts a hand to the bridge of his nose, as if trying to pinch off a frayed nerve or two.
    """
    read_prompt()
    print """
            "I don't... I'm still mad at him, you know? It's been so long but I'm still mad."
    """

######### CHOICE ONE #########

def choice_one_dialogue1():
    """Displays first set of choices to player."""

    print """
            Maybe you should text him back ...

            1. Ask him how his morning was.
            2. Tell him you're on your way.
            3. Leave him on read.
      """

def choice_one_response1():
    """Displays result of choice_one_response1."""

    print """
                You text back:
                >> good morning
                >> how are you?
                """
    read_prompt()

    print """
                Your phone buzzes again.
                >> :) hey
                >> doing all right, thx
                """

def choice_one_response2():
    """Displays result of choice_one_response2."""

    print """
                You text back:
                >> see u soon
                """
    read_prompt()

    print """
                Your phone buzzes again.
                >> k
                """

######### CHOICE TWO #########

def choice_two_dialogue1():
    """Plays scene after first choice and displays second choice."""

    second_scene()

    print """
            It only takes you 15 minutes to reach the lake.
            How should you let Thomas know you're here ...?

            1. Text him that you've arrived.
            2. Walk up to him and tap his shoulder.
            3. Throw a snowball at him.
    """

def choice_two_response1():
    """Displays result of choice_two_response1."""

    print """
            You pull your phone out:
            >> hey i'm here
    """
    read_prompt()

    print """
            A young man standing at the edge of the lake turns.
            He looks over at you and waves in recognition.
    """

def choice_two_response2():
    """Displays result of choice_two_response2."""
    print """
            You go up to Thomas and clap a hearty hand upon his shoulder.
            He startles beneath your touch and shrugs your hand off.
            "Christ, I told you not to scare me like that."
    """

def choice_two_response3():
    """Displays result of choice_two_response3."""
    print """
            Eyes glinting with mischief, you pack together a ball of snow.
            You wind your arm back, then...
    """
    read_prompt()
    print """
            SPLAT!
    """
    read_prompt()
    print """
            Thomas slowly turns around and gives you an unimpressed look.
    """

######### CHOICE THREE #########

def choice_three_dialogue1():
    """Plays scene after second choice and displays third choice."""

    third_scene()

    print """
            What do you say to someone in this sort of situation ...?

            1. It's not your place to comment on his family situation.
            2. It's natural to be mad. He shouldn't forgive his father.
            3. T'is the season to be merry and reconcile.
    """

def choice_three_response1():
    """Displays result of choice_one_response1."""
    print """
            You tell Thomas that you're sorry.
    """
    read_prompt()
    print """
            Thomas shrugs off your concern.
    """

def choice_three_response2():
    """Displays result of choice_one_response2."""
    print """
            You tell Thomas that his father can't expect forgiveness after all these years.
    """
    read_prompt()
    print """
            "Yeah, but that just makes me the bad guy, doesn't it?"
            He sounds so wistful.
    """

def choice_three_response3():
    """Displays result of choice_one_response3."""
    print """
            You tell Thomas that he'll never forgive himself if he doesn't do anything.
    """
    read_prompt()
    print """
            "Not what I wanted to hear, but... you're not wrong."
    """

######### ENDING BUFFER #########

def ending_buffer():
    """A small narrative buffer before an ending plays."""
    print """
            "Sorry for bringing it up. I'm just venting."
            Thomas sighs.
    """
    read_prompt()
    print """
            "Let's go make snow angels or whatever it is cool kids do."
    """

######### ENDINGS #########

def ending_one():
    """The 'bad' ending. Displays scene."""
    print """
            Years go by. You've long since forgotten that conversation you had with...
            What was his name again?

            You can't quite remember.


                    bad end.
        """

def ending_two():
    """The 'neutral' ending. Displays scene."""
    print """
            The following day, Thomas invites you to go last-minute shopping with him.
            While the two of you play with knick-knacks, the topic of his family never comes up.

            Just as well, you figure. It wasn't any of your business to begin with.
            What matters is that for just this day, just this moment, Thomas is smiling.


                    neutral end.
        """

def ending_three():
    """The 'best' ending. Displays scene."""
    print """
            Weeks pass. You and Thomas text back and forth intermittently throughout Winter Break.
            He's begun to open up a lot more to you lately.

            As it turns out, he's now in touch with his dad.
            He mentions their progress, every now and again.

            Last you heard, Thomas was rather excited about seeing the holiday lights with his father.
            You're proud of him and you tell him as much.


                    good end.
        """
