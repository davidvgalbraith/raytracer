import script

def update_tally(tally):
    """Retrieves the point value of the player's dialogue option."""

    return tally

def get_player_dialogue():
    """Determines which dialogue branch to direct player through."""

    player_choice = raw_input("(Please select a number.) > ")
    return player_choice

def ending_picker():
    """Checks value of relationship score tally. Prints appropriate ending."""

    if tally <= 2:
        script.ending_one()

    elif tally >= 3 and tally <= 5:
        script.ending_two()

    else:
        script.ending_three()

def choice_one():
    """Prompts user for their first decision. Updates relationship value depending on dialogue option."""

    script.choice_one_dialogue1()

    while True:

        player_choice = get_player_dialogue()

        if player_choice == "1":
            first_tally = update_tally(2)

            script.choice_one_response1()
            break

        elif player_choice == "2":
            first_tally = update_tally(1)

            script.choice_one_response2()
            break

        elif player_choice == "3":
            first_tally = update_tally(0)
            break

        else:
            print "Please select a valid dialogue option."

    script.read_prompt()
    return first_tally

def choice_two():
    """Displays dialogue between first and second choice. Updates relationship value depending on second dialogue option."""

    script.choice_two_dialogue1()

    while True:

        player_choice = get_player_dialogue()

        if player_choice == "1":
            second_tally = update_tally(2)

            script.choice_two_response1()
            break

        elif player_choice == "2":
            second_tally = update_tally(1)

            script.choice_two_response2()
            break

        elif player_choice == "3":
            second_tally = update_tally(-1)

            script.choice_two_response3()
            break

        else:
            print "Please select a valid dialogue option."

    script.read_prompt()
    return second_tally

def choice_three():
    """Displays dialogue between second and third choice. Updates relationship value depending on third dialogue option."""

    script.choice_three_dialogue1()

    while True:

        player_choice = get_player_dialogue()

        if player_choice == "1":
            third_tally = update_tally(0)

            script.choice_three_response1()
            break

        elif player_choice == "2":
            third_tally = update_tally(-1)

            script.choice_three_response2()
            break

        elif player_choice == "3":
            third_tally = update_tally(2)

            script.choice_three_response3()
            break

        else:
            print "Please select a valid dialogue option."

    script.read_prompt()
    script.ending_buffer()
    return third_tally

######### END OF COMPUTATIONAL FUNCTIONS #########

script.opening_scene()
tally = choice_one() + choice_two() + choice_three()
ending_picker()
