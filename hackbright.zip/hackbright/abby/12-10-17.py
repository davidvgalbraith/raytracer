# main bingo controller
import random


#FUNCTIONS

#start game
def start_game():
    """Intro to game, gets and returns user name"""
    print "Welcome to Bingo!"
    user_name = raw_input("What is your name? > ")
    print "Hi {}! You will be playing me in bingo today...are you feeling lucky?".format(user_name.title())
    print "The rules of this game are simple."
    print "I will generate a random BINGO card for each of us at the start of the game." '\n'
    print "Every time you play I will call a number."
    print "I will keep calling numbers until one of us wins."
    print "Hope you are wearing your lucky socks!"
    print "Get ready...."
    print '\n'
    return user_name

#make board
def make_board():
    """Makes BINGO board"""
    b_row = []
    while len(b_row) < 5:
        b = random.randint(1,15)
        if b not in b_row:
            b_row.append(b)

    i_row = []
    while len(i_row) < 5:
        i = random.randint(16,30)
        if i not in i_row:
            i_row.append(i)

    n_row = []
    while len(n_row) < 5:
        n = random.randint(31,45)
        if n not in n_row:
            n_row.append(n)

    g_row = []
    while len(g_row) < 5:
        g = random.randint(46,60)
        if g not in g_row:
            g_row.append(g)

    o_row = []
    while len(o_row) < 5:
        o = random.randint(61,75)
        if o not in o_row:
            o_row.append(o)

    game_board = []
    game_board.append(b_row)
    game_board.append(i_row)
    game_board.append(n_row)
    game_board.append(g_row)
    game_board.append(o_row)
    return game_board

#show board
def display_board(board):
    """shows board to user"""
    bingo = ["B ", "I ", "N ", "G ", "O "]
    print bingo[0], " ",bingo[1]," ", bingo[2]," ",bingo[3]," ",bingo[4]
    for x in range(5):
        if board[0][x] != "**":
            print "%02d" % board[0][x]," ",board[1][x]," ",board[2][x]," ",board[3][x]," ",board[4][x]
        else:
            print board[0][x]," ",board[1][x]," ",board[2][x]," ",board[3][x]," ",board[4][x]
    print '\n'

rolled_nums_in_game = []
#roll and store number
def roll_num():
    """Roll number, store number in a list """
    rolled_num = random.randint(1,75)
    roll = True

    while roll == True:
        if rolled_num not in rolled_nums_in_game:
            rolled_nums_in_game.append(rolled_num)
            if rolled_num <=15:
                print "Number Called -- B" + str(rolled_num)
            elif rolled_num <= 30:
                print "Number Called -- I" + str(rolled_num)
            elif rolled_num <= 45:
                print "Number Called -- N" + str(rolled_num)
            elif rolled_num <= 60:
                print "Number Called -- G" + str(rolled_num)
            else:
                print "Number Called -- O" + str(rolled_num)
            print
            break
        else:
            rolled_num = random.randint(1,75)
    return rolled_nums_in_game



#check if rolled number is on board
rolled_nums_on_board_list= []
def rolled_num_on_board(board, rolled_nums):
    """Checks if rolled number is on board. If on board that is passed in then it is stored in a list  """

    for item in board:
        for num in item:
            if num == rolled_nums[len(rolled_nums)-1]:
                rolled_nums_on_board_list.append(num)
    return rolled_nums_on_board_list



#create mark on board
def mark_the_board(board,rolled_nums):
    """Marks the board with the rolled numbers"""
    marked_board = board
    board[2][2] = "**"
    item_count = 0
    for item in marked_board:
        num_count = 0
        for num in item:
            if num in rolled_nums:
                marked_board[item_count][num_count] = "**"
            else:
                marked_board[item_count][num_count] = num
            num_count+=1
        item_count +=1
    return marked_board


#check if win
def check_win(board):
    """Pass in board and checks if a win condition is met, if win condition ends game"""
    #vertical win condition
    win = False

    for row in board:
        if row == ["**","**","**","**","**"]:
            win = True

    #horizontal win condition
    for x in range(5):
        count_in_horizontal = 0
        for row in board:
            if row[x] == "**":
                count_in_horizontal += 1

            if count_in_horizontal == 5:
                win = True

    #diagonal win condition
    if board[0][0] == "**" and board[1][1] == "**" and board[2][2] == "**" and board[3][3] == "**" and board[4][4] == "**":
        win = True
    if board[4][0] == "**" and board[3][1] == "**" and board[2][2] == "**" and board[1][3] == "**" and board[0][4] == "**":
        win = True

    return win


#GAME PLAY
user_name = start_game()
computer_board = make_board()
user_board = make_board()


while True:
    print "Menu:" '\n' "(a) Play" '\n' "(b) Display computer board" '\n' "(c) Quit"

    user_choice = raw_input("What would you like to choose? >> ")
    print '\n'
    if user_choice == "a":
        roll_num()

        rolled_num_on_board(user_board, rolled_nums_in_game)
        rolled_num_on_board(computer_board, rolled_nums_in_game)

        marked_player_board = mark_the_board(user_board,rolled_nums_on_board_list)
        print "Here is your board:"
        display_board(marked_player_board)

        marked_comp_board = mark_the_board(computer_board,rolled_nums_on_board_list)
        #print "Here is my board:"
        #display_board(marked_comp_board)

        #win sequence
        win_player = check_win(marked_player_board)
        win_comp = check_win(marked_comp_board)
        if win_player  == True:
            print "YOU WON!!!"
            break
        elif win_comp == True:
                print "I WON! Better luck next time!"
                break

    elif user_choice == "b":
        marked_comp_board = mark_the_board(computer_board, rolled_nums_on_board_list)
        print "Your wish is my command..."
        print "Here is my board:"
        display_board(marked_comp_board)

    elif user_choice == "c":
        print "Bye Bye"
        break

    else:
        print "That is not an option {}, choose 'a' 'b' or 'c'".format(user_name.title())



#end game




def win_art():
    print 
