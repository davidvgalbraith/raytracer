# i am creating functions here
import math
""" define the global guys here """
base = raw_input ("give the base  here >")
base = int(base)
power = raw_input("give the power here >")
power = int(power)
###############################################################

""" First create a function that gives me the power of any numbeer
I need the base , power to . Store the value in a variable . Make options to return the value to outside world. Here I creat local variables . """
def get_me_the_power(base,power):
    raised_to_power = base ** power
    return raised_to_power

""" Here convert the power value to strings"""

def covert_power_values_strings():
    answer_from_last_func = get_me_the_power(base,power)
    print answer_from_last_func
    return str(answer_from_last_func)


    ########## This is global for the add_strings_func#####
stringed_val = covert_power_values_strings()
################################################################
def remove_dot_and_zero(stringed_val):
    """ Here the function math.pow gives values in float format"""
    stringed_val = stringed_val.strip("0")
    stringed_val = stringed_val.strip(".")
    stringed_val = stringed_val.strip("L")
    new_value = stringed_val
    return new_value

new_value = remove_dot_and_zero(stringed_val)

def add_strings_func(new_value):
    """ Here we are converting the stringed digits and adding them
    """
    my_list = list(new_value)
    #print type(my_list)
    for i in my_list:
        print i
    print my_list
    length_list = len(my_list)
    i = 0
    total = 0
    while i <= length_list -1:
        total = total + int(my_list[i])
        i = i + 1
    print  "The value added in the function call is ",total
    return total




###################MAin Program###################
#print type(covert_power_values_strings())
#print covert_power_values_strings()
#Final_total_of_digits = add_strings_func(stringed_val)
#print "Base is {},power is {}, added_value is {}".format(base,power,Final_total_of_digits)
print "This is the stringed value for the power function",stringed_val
print "Here the dot and the zero got removed ",new_value
print "Here the final result where all the digits got added"
print add_strings_func(new_value)
