

# Part 2: Road Class
# #############################################################################

# Create your Road class here
class Road(object):
    num_lanes = 2
    speed_limit = 25

    def __init__(self):
        pass

# Instantiate Road objects here
road_1 = Road()
road_1.num_lanes = 4
road_1.speed_limit = 60

road_2 = Road()

# Part 3: Update Password
# #############################################################################
class User(object):
    """A user object."""

    def __init__(self, username, password):
        self.username = username
        self.password = password

    # write the update_password method here
    def update_password(self,current_password, new_password):
        if current_password == self.password:
            self.password = new_password
        else:
            print "Invalid password"

# Part 4: Build a Library
# #############################################################################
class Book(object):
    """A Book object."""


    def __init__(self, title, author):
        self.title = title
        self.author = author

# Create your Library class here
class Library(object):

    def __init__(self):
        self.books = []

    def add_book(self, title, author):
        new_book = Book(title, author)
        self.books.append(new_book)

    def find_books_by_author(self, author):
        authored_books =[]
        #check each book object in the book list for self.author
        for book in self.books:
            if author == book.author:
                authored_books.append(book)

        return authored_books


# Part 5: Rectangles
# #############################################################################

class Rectangle(object):
    """A rectangle object."""

    def __init__(self, length, width):
        self.length = float(length)
        self.width = float(width)

    def calculate_area(self):
        """Return the rectangle's area (length * width)."""
        return self.length * self.width


# Create the Square class here
class Square(Rectangle):

    def __init__(self, length, width):
        super(Rectangle, self).__init__()
