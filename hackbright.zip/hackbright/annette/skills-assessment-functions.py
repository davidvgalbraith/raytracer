"""
Skills function assessment.

Please read the instructions first. Your solutions should
go below this docstring.

"""

###############################################################################

# PART ONE: Write your own function declarations.

# NOTE: We haven't given you function signatures or docstrings for these, so
# you'll need to write your own.

#    (a) Write a function that takes a town name as a string and returns
#        `True` if it is your hometown, and `False` otherwise.

#    (b) Write a function that takes a first and last name as arguments and
#        returns the concatenation of the two names in one string.

#    (c) Write a function that takes a home town, a first name, and a last name
#        as arguments, calls both functions from part (a) and (b) and prints
#        "Hi, 'full name here', we're from the same place!", or "Hi 'full name
#        here', I'd like to visit 'town name here'!" depending on what the function
#        from part (a) evaluates to.

###############################################################################

def is_hometown(hometown):
    """Determines if an input hometown is my hometown

    >>> is_hometown("San Francisco")
    True

    >>> is_hometown("Las Vegas")
    False

    """

    hometown = hometown.title()

    if hometown == "San Francisco":
        return True
    else:
        return False


def make_fullname(fristname, lastname):
    """Takes a first and last name as arguments and
    returns the concatenation of the two names in one string

    >>> make_fullname("Annette", "Ambriz")
    'Annette Ambriz'

    """
    fristname = fristname.capitalize()
    lastname = lastname.capitalize()

    return fristname + " " + lastname


def make_name_hometown(hometown, fristname, lastname):
    """Takes a first and last name as arguments and
    returns the concatenation of the two names in one string

    >>> make_name_hometown("San Francisco", "Annette", "Ambriz")
    Hi, Annette Ambriz, we're both from the same place!

    >>> make_name_hometown("New York", "Tim", "Burton")
    Hi, Tim Burton, I'd like to visit New York!

    """
    fullname = make_fullname(fristname, lastname)
    hometown = hometown.title()

    if is_hometown(hometown) == True:
        print "Hi, {}, we're both from the same place!".format(fullname)
    else:
        print "Hi, {}, I'd like to visit {}!".format(fullname, hometown)


###############################################################################

# PART TWO

#    (a) Write a function, `is_berry()`, which takes a fruit name as a string
#        and returns a boolean if the fruit is a "strawberry", "raspberry",
#        "blackberry", or "currant."

#    (b) Write another function, shipping_cost(), which calculates shipping
#        cost by taking a fruit name as a string and calling the `is_berry()`
#        function within the `shipping_cost()` function. Your function should
#        return 0 if is_berry() == True, and 5 if is_berry() == False.

#    (c) Make a function that takes in a fruit name and a list of fruits. It should
#        return a new list containing the elements of the input list, along with
#        given fruit, which should be at the end of the new list.

#    (d) Write a function calculate_price to calculate an item's total cost by
#        adding tax and any fees required by state law.

#        Your function will take as parameters (in this order): the base price of
#        the item, a two-letter state abbreviation, and the tax percentage (as a
#        two-digit decimal, so, for instance, 5% will be .05). If the user does not
#        provide a tax rate it should default to 5%.

#        CA law requires stores to collect a 3% recycling fee, PA requires a $2
#        highway safety fee, and in MA, there is a Commonwealth Fund fee of $1 for
#        items with a base price of $100 or less and $3 for items over $100. Fees are
#        added *after* the tax is calculated.

#        Your function should return the total cost of the item, including tax and
#        fees.

##############################################################################

def is_berry(fruit):
    """Determines if fruit is a berry

    >>> is_berry("blackberry")
    True

    >>> is_berry("durian")
    False

    """
    berry_list = ["strawberry", "raspberry", "blackberry", "currant"]

    if fruit in berry_list:
        return True
    else:
        return False


def shipping_cost(fruit):
    """Calculates shipping cost of fruit

    >>> shipping_cost("blackberry")
    0

    >>> shipping_cost("durian")
    5

    """
    if is_berry(fruit) == True:
        return 0
    else:
        return 5

def append_to_list(lst, fruit):
    """Returns a new list consisting of the old list with the given number
       added to the end.

    >>> append_to_list(['banana', 'apple', 'blackberry'], 'dragonfruit')
    ['banana', 'apple', 'blackberry', 'dragonfruit']

    >>> fruits = ['banana', 'apple', 'blackberry']
    >>> append_to_list(fruits, 'dragonfruit')
    ['banana', 'apple', 'blackberry', 'dragonfruit']
    >>> fruits
    ['banana', 'apple', 'blackberry']

    """
    fruit = str(fruit)
    new_list = list(lst)
    new_list.append(fruit)
    return new_list

CA_FEE = 0.03
PA_FEE = 2.0
MA_FEE1 = 1.0
MA_FEE2 = 3.0
DEFAULT_TAX = 0.05

def calculate_price(baseprice, state, tax_rate=DEFAULT_TAX):
    """Calculate total price of an item, figuring in state taxes and fees.

    >>> calculate_price(40, "CA")
    43.26

    >>> calculate_price(400, "NM")
    420.0

    >>> calculate_price(150, "OR", 0.0)
    150.0

    >>> calculate_price(60, "PA")
    65.0

    >>> calculate_price(38, "MA")
    40.9

    >>> calculate_price(126, "MA")
    135.3

    """
    if state == "CA":
        total_bill = (baseprice * tax_rate) + baseprice
        total_bill = (total_bill * CA_FEE) + total_bill

    elif state == "PA":
        total_bill = (baseprice * tax_rate) + baseprice + PA_FEE

    elif state == "MA":
        if baseprice <= 100:
            total_bill = (baseprice * tax_rate) + baseprice + MA_FEE1
        elif baseprice > 100:
            total_bill = (baseprice * tax_rate) + baseprice + MA_FEE2

    else:
        total_bill = (baseprice * tax_rate) + baseprice

    return total_bill


###############################################################################

# PART THREE

# NOTE: We haven't given you function signatures and docstrings for these, so
# you'll need to write your own.

#    (a) Make a new function that takes in a list and any number of additional
#        arguments, appends them to the list, and returns the entire list. Hint: this
#        isn't something we've discussed yet in class; you might need to google how to
#        write a Python function that takes in an arbitrary number of arguments.

#    (b) Make a new function with a nested inner function.
#        The outer function will take in a word.
#        The inner function will multiply that word by 3.
#        Then, the outer function will call the inner function.
#        Print the output as a tuple, with the original function argument
#        at index 0 and the result of the inner function at index 1.

#        Example:

#        >>> outer("Balloonicorn")
#        ('Balloonicorn', 'BalloonicornBalloonicornBalloonicorn')


###############################################################################
#    (a) Make a new function that takes in a list and any number of additional
#        arguments, appends them to the list, and returns the entire list. Hint: this
#        isn't something we've discussed yet in class; you might need to google how to
#        write a Python function that takes in an arbitrary number of arguments.
###############################################################################
    """Returns a list of all the arguments given

    >>> list_allthe_things(1, 2, "three", 4.5)
    [1, 2, "three", 4.5]
    """

def list_allthe_things(*args):
    list_of_arguments = []
    for arg in args:
        list_of_arguments.append(arg)

    return list_of_arguments


###############################################################################
# (b) Make a new function with a nested inner function.
#        The outer function will take in a word.
#        The inner function will multiply that word by 3.
#        Then, the outer function will call the inner function.
#        Print the output as a tuple, with the original function argument
#        at index 0 and the result of the inner function at index 1.

#        Example:

#        >>> outer("Balloonicorn")
#        ('Balloonicorn', 'BalloonicornBalloonicornBalloonicorn')

def prints_Thrice(word):
    """Prints the output as a tuple, with the original function argument
      at index 0 and the result of the inner function at index 1.

    >>> prints_Thrice("Annette")
    ('Annette', 'AnnetteAnnetteAnnette')

    >>> prints_Thrice("Balloonicorn")
    ('Balloonicorn', 'BalloonicornBalloonicornBalloonicorn')
    """
    #inner function returns the arugment as a joined word list repheated three times
    def times_three(word):
        word_list = []
        for n in range(0,3):
            word_list.append(word)
        word_list = "".join(word_list)
        return word_list

   #parent funciton calling inner function
   #creates a tuple, with the original function argument at index 0 and the result of
   #the inner function at index 1.
    three_word_tuple = (word, times_three(word))

    print three_word_tuple


# END OF ASSESSMENT: You can ignore everything below.

if __name__ == "__main__":
    import doctest

    print
    result = doctest.testmod()
    if not result.failed:
        print "ALL TESTS PASSED. GOOD WORK!"
    print

"""
- Nice use of .title() in is_hometown!
- Great docstrings! I like how you wrote some tests for yourself.
- Code like this:

    if hometown == "San Francisco":
        return True
    else:
        return False

that checks a condition and returns True if the condition is True and False if the condition is False can be simplified to:

return hometown == "San Francisco"

- Nice use of constants and the default argument for calculate_price!
- list_allthe_things doesn't quite do what the instructions call for. The first argument is intended to be a list, and then it appends all the other arguments to that first list. Like this:
    >>> list_allthe_things([1, 2], "three", 4.5)
    [1, 2, "three", 4.5]
- In times_three, it'd be clearer to use a new variable name instead of word_list for "".join(word_list) because it's now a string instead of a list. times_three would also benefit from a docstring.

Summary:
Correctness: +64/69
Style: +29/31

= 93

Solid work on this! I'm glad we were able to track it down.
"""
