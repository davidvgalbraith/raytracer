from random import randint
from deck import deck

OPTIONS = """
    (N)ew game
    (C)heck score
    (E)xit
    """
PLAY_OPTIONS = """
    (H)it
    (S)tay
    """
#title setting to display dealer's hand
DISPLAY_DEALER = """
    Dealer's hand
        """
#title setting to display user's hand
DISPLAY_USER = """
    Your hand
        """

def player_hit(hand):
    """Get another random card added to a hand"""
    card = randint(1, 12)
    new_hand = hand.append(card)
    return new_hand

def check_bust(hand):
    """Checks if either player's hands is over 21"""
    if hand > 21:
        return True
    else:
        return False

def show_card(hand):
    """Display illustrated cards imported from deck.py"""
    for card in hand:
        print (deck(card))
    return "................"    #would show None in the terminal if it didn't return something...

def display_hands(dealers_hand, users_hand):
    """Displays both dealer and user's hands, instead of repeatedly typing this, made into func"""
    print DISPLAY_DEALER, show_card(dealers_hand)
    print DISPLAY_USER, show_card(users_hand)


def winner(users_hand, users_total, dealers_hand, dealers_total):
    """Determines outcome and displays both dealer and user's hand"""

    if users_total == dealers_total:    #if both hands are equal
        print "Final hands..."
        display_hands(dealers_hand, users_hand)
        print "\nIt's a tie!"
        return None

    elif users_total <= 21 and users_total > dealers_total or dealers_total > 21: #if user has the winning hand, 21 or higher hand than dealer
        print "Final hands..."
        display_hands(dealers_hand, users_hand)
        print "\nYou win!"
        return True

    elif dealers_total <= 21 and dealers_total > users_total or users_total > 21: #if dealer has winning hand, 21 or higher hand than user
        print "Final hands..."
        display_hands(dealers_hand, users_hand)
        print "\nDealer wins!"
        return False

    else:           #Just in case something didn't turn out right
        print "Something went wrong, cannot determine outcome..."
        display_hands(dealers_hand, users_hand)
        return None

def game_play():
    """Play a game of blackjack"""
    users_hand = []     #setting up empty list to contain user's "cards"
    dealers_hand = []   # setting up empty list to contian dealer's "cards"

    player_hit(users_hand)  #draw one random card, put into user's hand
    player_hit(users_hand)     #draw another random card, put into user's hand

    player_hit(dealers_hand)       #draw one random card, put into dealer's hand

    display_hands(dealers_hand, users_hand)

    #will continue to loop while user types H and their hand is under 21
    while True:
        print "\nWhat would you like to do?"
        print PLAY_OPTIONS

        input = raw_input("> ").upper()

        if input == "H":
            player_hit(users_hand)      #takes a card


            users_total = 0         #so it will start counting from the first card
            for card in users_hand:
                if card < 10:       #will count cards 1 to 9
                    users_total += card
                else:               #these will be face cards that still count as 10
                    users_total += 10


            if check_bust(users_total) == True:     #once user busts, loop will break, and go on to the dealer
                print "\n"
                print DISPLAY_USER, show_card(users_hand)
                print "\nBUST! Game over..."
                break

            else:                                   #if user doesn't bust, cards will be displayed, game continues
                print "\n"
                print DISPLAY_USER, show_card(users_hand)

        elif input == "S":
            users_total = 0         #will start counting from the first card
            for card in users_hand:
                if card < 10:
                    users_total += card
                else:
                    users_total += 10
            break

        else:
            print "That's not a valid option."

    #now it's the dealer's turn
    if check_bust(users_total) == True: #if user busts, dealer "flips" over their card, and has automatic win
        player_hit(dealers_hand)
        print DISPLAY_DEALER, show_card(dealers_hand)  #so user can see the card the dealer is getting

        dealers_total = 0               #start count from first card
        for card in dealers_hand:
            if card < 10:               #number cards
                dealers_total += card
            else:                       #face cards
                dealers_total += 10
        raw_input("\nENTER to continue...")     #slows down the game

    else:                               #if user doesn't bust, dealer continues the game
        dealers_total = 0
        while dealers_total <= 17:
            player_hit(dealers_hand)
            print DISPLAY_DEALER, show_card(dealers_hand)  #so user can see the cards the dealer is getting

            dealers_total = 0
            for card in dealers_hand:
                if card < 10:           #number cards
                    dealers_total += card
                else:                   #face cards
                    dealers_total += 10

            if check_bust(dealers_total) == True:       #checks if dealer busts
                print "\n"
                print "\nBUST! Game over..."

            raw_input("\nENTER to continue...")     #slows down the game


    score = winner(users_hand, users_total, dealers_hand, dealers_total)
    return score    #stored into score variable to add a point towards the winner in the if/else condition in main func

def game_setup():
    """Starting a game of blackjack"""

    print "Welcome to the Blackjack corner!\n"
    print "Where everything's a risk and no one's safe!\n"
    print "Unfortunately, for simplicity's sake in this game, an Ace is considered one.\n"
    print "Now, who do I have the pleasure of speaking to? "
    player = raw_input("> ").capitalize()
    print "\nGreat {}, here are your options:".format(player)

    users_score = 0     #used to keep score
    dealers_score = 0

    while True:         #will loop while user wants to play a game or check the scores
        print OPTIONS
        input = raw_input("> ").upper()

        if input == "N":
            point = game_play()     #point variable to dictate who gets the point
            if point == True:       #if winner func returns True, user gets a point
                users_score += 1
            elif point == False:    #if winner func returns False, dealer gets a point
                dealers_score += 1
            else:                   #if game resulted in a tie or something went wrong
                print "No one gets a point..."

            print "\n\n\n\nPlay again?"

        elif input == "C":      #display scores
            print
            print "Your score:", users_score
            print
            print "Dealer's score:", dealers_score

            print"\n\n\n\nWhat do you want to do?"

        elif input == "E":
            print "\nUntil next time, {}...".format(player)
            break

        else:
            print "That is not a valid option, {}.".format(player)

game_setup()
