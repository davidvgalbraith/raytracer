"""
Part 1: Discussion

1. What are the three main design advantages that object orientation
   can provide? Explain each concept.
The three main design advantages that object orientation can provide are encapsulation, or where data lives close to its functionality; abstraction, or the ability to use a method without knowing the information a method uses internally; and polymorphism, or the easy capability to make different, interchangeable types of a thing wihtout conditionals.
2. What is a class?
A class is a Type of a thing. Collections such as lists and tuples are also examples of types of classes.
3. What is a method?
A method is like a function that is built into a class.
4. What is an instance in object orientation?
An instance is an individual occurance of a class.
5. How is a class attribute different than an instance attribute?
   Give an example of when you might use each.
They are slightly different. A class attribute is a datapoint that lives on the class. When it is used on an instance, that instance finds that datapoint in the class. However, unlike the class attribute, the instance attribute is set directly on the object.
"""


# Part 2: Road Class
# #############################################################################

# Create your Road class here
class Road(object):
    num_lanes = 2
    speed_limit = 25


# Instantiate Road objects here
road_1 = Road()
road_2 = Road()

road_1.num_lanes = 4
road_1.speed_limit = 60


# Part 3: Update Password
# #############################################################################
class User(object):
    """A user object."""

    def __init__(self, username, password):
        self.username = username
        self.password = password

    # write the update_password method here
    def update_password(self, current_password, new_password):
        if current_password != self.password:
            print "Invalid password"
        elif current_password == self.password:
            self.password = new_password

# Part 4: Build a Library
# #############################################################################
class Book(object):
    """A Book object."""

    def __init__(self, title, author):
        self.title = title
        self.author = author

# Create your Library class here
class Library(object):
    """An object that holds books"""

    def __init__(self):
        self.books = []

    def add_book(self, title, author):
        book = Book(title, author)
        self.books.append(book)

    def find_books_by_author(self, author):
        books_by_author = []
        for book in self.books:
            if book.author == author:
                books_by_author.append(book)
        return books_by_author

        pass

# Part 5: Rectangles
# #############################################################################

class Rectangle(object):
    """A rectangle object."""

    def __init__(self, length, width):
        self.length = float(length)
        self.width = float(width)

    def calculate_area(self):
        """Return the rectangle's area (length * width)."""
        return self.length * self.width


# Create the Square class here
class Square(Rectangle):
        """A square object, a subclass of rectangle."""
        def __init__(self, length):
            super(Square, self).__init__(length, 'length')

        def calculate_area(self, length):
            """Return the rectangle's area (length * width)."""
            if width == length:
                area = super(Square, self).calculate_area(length)
            else:
                print "Invalid Square"
                return None
