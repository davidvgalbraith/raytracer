class Book(object):
    """A Book object."""

    def __init__(self, title, author):
        self.title = title
        self.author = author

    def print_title(self):
        print "my title is", self.title

class Biography(Book):
    def __init__(self, title, author, subject):
        self.subject = subject
        return super(Biography, self).__init__(title, author)

my_life = Biography("My Life", "Bill Clinton", "Bill Clinton")
my_life.print_title()
