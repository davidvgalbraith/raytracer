game_board =[[" "," "," "," "," "," ", " "],[" "," "," "," ", " "," ", " "],[" "," "," "," ", " "," ", " "],[" "," "," "," "," "," ", " "],[" "," "," "," "," "," ", " "],[" "," "," "," "," "," ", " "]]
import random
user_turn = True
free_space = 42

def show_board(board):
	"""Creates a game board. Each square is an index that will later hold each player's move.   """

	print " 0     1     2     3     4     5     6"
	print   board[0][0], " | ", board[0][1], " | ", board[0][2], " | ", board[0][3],  " | ", board[0][4], " | ", board[0][5], " | ", board[0][6]
	print "---------------------------------------"
	print	board[1][0], " | ", board[1][1], " | ", board[1][2], " | ", board[1][3],  " | ", board[1][4], " | ", board[1][5], " | ", board[1][6]
	print "---------------------------------------"
	print	board[2][0], " | ", board[2][1], " | ", board[2][2], " | ", board[2][3],  " | ", board[2][4], " | ", board[2][5], " | ", board[2][6]
	print "---------------------------------------"
	print	board[3][0], " | ", board[3][1], " | ", board[3][2], " | ", board[3][3],  " | ", board[3][4], " | ", board[3][5], " | ", board[3][6]
	print "---------------------------------------"
	print	board[4][0], " | ", board[4][1], " | ", board[4][2], " | ", board[4][3],  " | ", board[4][4], " | ", board[4][5], " | ", board[4][6]
	print "---------------------------------------"
	print	board[5][0], " | ", board[5][1], " | ", board[5][2], " | ", board[5][3],  " | ", board[5][4], " | ", board[5][5], " | ", board[5][6]


def start_game():
    """Initiates the game by asking if the user wants to start or the 'computer'"""

    choice = raw_input("Would you like to make the first move? (y or n): ")
    if choice == 'y' or choice =='Y':
        user_turn = True
    elif choice == 'n' or choice =='N':
        user_turn = False
    else:
        print "Invalid entry"
    return user_turn


def user_move(board):
    """Allow player to drop a piece as long as that space is not taken"""

    #indicates if space is taken
    valid_space = True

    #indicates that its the user's turn
    user_turn = True

    #while the space is available and it's the user's turn, a string ('X') is assigned to an index t

    while valid_space and user_turn:
        column = input("Select a column (0-6): ")
        for row in range(5,-1,-1):
            if 0 <= row <= 5 and 0 <= column <= 6 and board[row][column] == " ":
                board[row][column] = 'X'
                valid_space = False
                user_turn = False
                break

def computer_move(board):
    """Allow computer to drop a piece in a valid spot"""

    valid_space = True
    user_turn = False
    while valid_space and not user_turn:
        column = random.randint (0,6)
        for row in range(5,-1,-1):
            if 0 <= row <= 5 and 0 <= column <= 6 and board[row][column] == " ":
                board[row][column] = 'O'
                valid_space = False
                user_turn = True
                break

def check_winner(board):
    """Four consecutive spaces, vertically and horizontally, are needed to win. X or Y is returned, depending on who wins"""

    #check rows for a winner
    for row in range(6):
        for column in range(4):
            if board[row][column] == board[row][column + 1] == board[row][column + 2]  == board[row][column + 3] and board[row][column] != " ":
                return board[row][column]

    #check column for a winner
    for column in range(7):
        for row in range(3):
            if board[row][column] == board[row + 1][column] == board[row + 2][column] == board[row + 3][column] and board[row][column] != " ":
                return board[row][column]

    #check diagonal for a winner, top-left (nice to have)

    #check diagonal for a winner, bottom left to top right (nice to have)

    #no winner: return empty space
    return " "

def play_game():
    """A function that passes other functions and allows us to run the game"""
    #Calling this function asks if the user wants to go first
    user_choice = start_game() #t/f
    if user_choice == True:
            #This variable will be used to alternate turns between user and computer
        user_turn = True
    else:
        user_turn = False

    show_board(game_board)
    #This variable tells us how many spaces are available
    free_space = 42

    computer_turn = 2
    #After we start the game, the board is shown

    #Allow user and computer to make moves until winner or spaces are taken
    while check_winner(game_board) != "X" or check_winner(game_board) != "Y" or check_winner(game_board) != " " and free_space > 0:
        if user_turn:
            user_move(game_board)
            user_turn = False
            free_space -= 1
            show_board(game_board)
        elif not user_turn:
            computer_move(game_board)
            user_turn = True
            free_space -= 1
            show_board(game_board)
        #If we have a winner, print who won and end game
        if check_winner(game_board) == 'X':
            show_board(game_board)
            print "Congrats! You won!"
            print "Game Over"
            break
        elif check_winner(game_board) == 'O':
            show_board(game_board)
            print "Computer won!"
            print "Game Over"
            break
        elif free_space == 0:
            show_board(game_board)
            print "Tie!"
            print "Game Over"
            break
        #Each move takes away a free space; when free space is 0 we have tie

play_game()
