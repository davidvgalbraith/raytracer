### Lists, Strings, and Dictionaries

spells = ['expelliarmus', 'petrificus totalis', 'wingardium leviosa', 'riddikulus', 'lumos solem']

empirical_spells = ['expelliarmus', 'petrificus totalis', 'wingardium leviosa', 'riddikulus', 'lumos solem']



magical_items =  ['bezoar', 'broom', 'dark detector', 'deluminator']

thick_darkness_dict = {
    "meta": "thick darkness",
    "scenario": "Whoa. You've been plunged into thick darkness. You can't even see your wand.",
    "defenses": ['lumos solem', 'deluminator'],
    "defense_query": "Do you have either Lumos Solem or a Deluminator?"
}

noxious_fumes_dict = {
    "meta": "noxious fumes",
    "scenario": "Yikes! You are enveloped by noxious fumes. You've only got seconds before you lose consciousness.",
    "defenses": ['bezoar'],
    "defense_query": "Do you have a bezoar?"
}

troll_dict = {
    "meta": "nine foot mountain troll",
    "scenario": "Look out! It's a nine foot mountain troll, and that club of his looks deadly.",
    "defenses": ['petrificus totalis', 'wingardium leviosa', "broom"],
    "defense_query": "Do you have either Petrificus Totalis or Wingardium Leviosa? Or maybe a broom?"
}

boggart_dict = {
    "meta": "boggart",
    "scenario": "Oh no! It's a boggart.",
    "defenses": ['riddikulus'],
    "defense_query": "Do you have Riddikulus?"
}

dark_situations = [thick_darkness_dict, noxious_fumes_dict, troll_dict, boggart_dict]


greeting_game_description = '''In this duel you only have a spell and a magical item,
each randomly selected by the gargoyle. Each can help you get to safety, and hopefully
you'll get something you can use. If not, the Magical Retrival Squad will attempt
to retrieve you and you can try again.'''


### Imports

import time
import random
from random import randint
from random import choice


### NOT USING THESE Functions

def random_num(game_list):
    """returns random number based on length of list -- DO I NEED THIS ANYMORE?"""
    length_list = len(game_list)
    random_num = randint(0, length_list-1)
    return random_num

def big_things_happening_pause():
    """creates a visual pause in the game, as if something is happening"""
    print "."
    time.sleep(1)
    print "."
    time.sleep(1)
    print "."
    time.sleep(1)



### Functions

def get_user_name():
    """returns user name"""
    name = raw_input("What is your name?  > ")

    while name == "":
        name = raw_input("What is your name?  > ")

    name = name.capitalize()
    return name



def visual_separator():
    print "~ - ~ - ~ - ~"

def item_presentation(item):
    """presents spell or magical item in a visually pleasing way"""
    visual_separator()
    print "{}!".format(item)
    visual_separator()



def get_spell():
    """creates a visual delayed lead-up to delivering the player's spell"""
    print "The gargoyle"
    time.sleep(2)
    print "is summoning"
    time.sleep(2)
    print "your spell."
    time.sleep(1)
    spell = choice(spells)
    x = spells.index(spell)
    spells.pop(x)
    spell = spell.title()
    item_presentation(spell)
    spell = are_you_happy(spell)
    return spell


def are_you_happy(spell):
    """ask user is ze wants a diff thing"""

    replace_item = raw_input("Are you happy with what the G gave you? >")

    if replace_item == "no":
        new_spell = get_spell()
        return new_spell

    elif replace_item == "yes":
        return spell

    else:
        print "moving on..."
        return spell




def get_magical_items():
    """creates a visual delayed lead-up to delivering the player's magical item"""
    print "The gargoyle is retrieving"
    time.sleep(1)
    print "a magical item"
    time.sleep(1)
    print "for you to use."
    time.sleep(1)
    magical_item = choice(magical_items).title()
    item_presentation(magical_item)
    return magical_item




def print_situation(my_situation_dict):
    print my_situation_dict["scenario"]
    print my_situation_dict["defense_query"]
    time.sleep(1)


def oh_snap():
    print " "
    print """Oh snap! That's got to hurt. Don't worry! The magical reversable squad
    will come for you and take you to St. Mungo's if necessary."""



def play_one_round():

    player_spell = get_spell()
    player_magical_item = get_magical_items()
    print "Well, that's promising, {} and a {}. Could be a lot worse.".format(player_spell, player_magical_item)
    print "Okay, when I open this door you'll be confronted with a Dark Situation. Good Luck!"
    time.sleep(1)
    print "Ready?"
    time.sleep(1)
    print "One..."
    time.sleep(1)
    print "Two..."
    time.sleep(1)
    print "I'm going to open this door on \"Three\""
    time.sleep(1)
    print "Three!"

    dark_situation = choice(dark_situations)
    print_situation(dark_situation)

    if dark_situation == thick_darkness_dict:
        if str(player_spell) == "Lumos Solem":
            print " "
            print "Thank Merlin! Quick, cast that spell and you'll get through!"

        elif str(player_magical_item) == "Deluminator":
            print " "
            print "What are you waiting for?! Use it!!!!"

        else:
            oh_snap()

    elif dark_situation == noxious_fumes_dict:
        if str(player_magical_item) == "Bezoar":
            print " "
            print "Quick! Shove that thing down your throat and swallow!"

        else:
            oh_snap()

    elif dark_situation == boggart_dict:
        if str(player_spell) == "Riddikulus":
            print " "
            print "Oh that's scary! Think of something funny quick!"

        else:
            oh_snap()

    elif dark_situation == troll_dict:
        if str(player_spell) == "Petrificus Totalis":
            print " "
            print "Thank Merlin! Quick, cast that spell and you can get around it!"

        elif str(player_spell) == "Wingardium Leviosa":
            print " "
            print "Thank Merlin! Quick, cast that spell to raise that club and run around it!"

        elif str(player_magical_item) == "Broom":
            print " "
            print "What are you waiting for?! Get on and fly above it!"

        else:
            oh_snap()




### ------------------
### Start game

print str(greeting_game_description)

player_name = get_user_name()
time.sleep(1)
print "Okay {}, get ready to duel. Let's get your defenses.".format(player_name)

speak_gargoylish = raw_input("Do you speak Gargoylish? > ")
speak_gargoylish = speak_gargoylish.lower()

if speak_gargoylish == "yes":
    time.sleep(1)
    print "That's a relief."
    time.sleep(1)
elif speak_gargoylish == "no":
    time.sleep(1)
    print "Well, that sucks."
    time.sleep(1)
    print "You're just going to have to wing it."
    time.sleep(1)
else :
    time.sleep(2)
    print "Huh?"
    time.sleep(1)
    print "Never mind -- no time to figure it out. You're just going to have to wing it."
    time.sleep(1)

print " "
print "I'll help summon your spell and magical item from the gargoyle."


## ------------------
## Play the game
play = True

while play:
        play_one_round()
        time.sleep(1)

        play_again = raw_input("Do you want to try again? yes or no?  > ")
        play_again = play_again.lower()
        if play_again == 'yes':
            print "Great! Let's try this again."
            spells = empirical_spells
            time.sleep(1)

        elif play_again == 'no':
            print "Thanks for dueling. Bye."
            play = False

        else:
            print """I'm sorry, Dave. I can't do that. Yes or no seemed a straightforward question.
            St. Mungo's for you. Bye."""
            play = False






# NOT USING THIS CODE:
#    """uses randomized_num to pull an item from a list"""
#    your_item = game_list.pop(random_num)
#    return your_item
#   random_num = random_num(spells)
#   random_num = random_num(magical_items)
