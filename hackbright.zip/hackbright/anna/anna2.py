## dictionary to allow user to select specific squares

complete_row_1 = ('1', '2', '3', '4')
complete_row_2 = ('3', '4', '2', '1')
complete_row_3 = ('2', '1', '4', '3')
complete_row_4 = ('4', '3', '1', '2')

COMPLETE_REFERENCE_PUZZLE = (complete_row_1, complete_row_2, complete_row_3, complete_row_4)

# 4x4 completed reference puzzle, within grid
board_grid_columns = ['A', 'B', 'C', 'D']
board_grid_rows = ['W', 'X', 'Y', 'Z']
board_grid = board_grid_columns + board_grid_rows

# single-variable challenge
start_row_1 = ['1', '2', 'x', '4']
start_row_2 = ['3', '4', '2', '1']
start_row_3 = ['2', '1', '4', '3']
start_row_4 = ['4', '3', '1', '2']

# initial challenge
# start_row_1 = ['1', '2', 'x', '4']
# start_row_2 = ['3', 'x', '2', 'x']
# start_row_3 = ['x', '1', '4', '3']
# start_row_4 = ['4', '3', 'x', '2']

active_guess_puzzle = [start_row_1, start_row_2, start_row_3, start_row_4]

complete_row_1 = ['1', '2', '3', '4']
complete_row_2 = ['3', '4', '2', '1']
complete_row_3 = ['2', '1', '4', '3']
complete_row_4 = ['4', '3', '1', '2']

COMPLETE_REFERENCE_PUZZLE = [complete_row_1, complete_row_2, complete_row_3, complete_row_4]


# resultset = (['James Taylor'], ['Sarah Jarosz'], ['Crooked Still'])
# new_list = [i[0] for i in resultset]
# reference_check = [i[0:] for i in COMPLETE_REFERENCE_PUZZLE]
# complete_reference_check = [i[0:] for i in reference_check]

# flat_list = [item for sublist in l for item in sublist]
# which means:

# for sublist in l:
#     for item in sublist:
#         flat_list.append(item)
# is faster than the shortcuts posted so far. (l is the list to flatten.)

# Here is a the corresponding function:
# flatten = lambda l: [item for COMPLETE_REFERENCE_PUZZLE in l for item in COMPLETE_REFERENCE_PUZZLE]
# I'm sure you've seen (if not used used) the str() type-cast function before, well same thing here with list()..

# >>> t = ('my', 'name', 'is', 'mr', 'tuple')
# >>> t
# ('my', 'name', 'is', 'mr', 'tuple')
# >>> l = list(t)
# >>> l
# ['my', 'name', 'is', 'mr', 'tuple']
ref_chk = list(COMPLETE_REFERENCE_PUZZLE[0:])
# ref_chk_chk = list(ref_chk)
# new_new = [i[0] for i in COMPLETE_REFERENCE_PUZZLE]
# new_list = [i[0] for i in ref_chk]


# reference_check = [i[0:] for i in COMPLETE_REFERENCE_PUZZLE]
# complete_reference_check = [i[0:] for i in reference_check]


print "Here is the puzzle:"
print
print "  " + str(board_grid_columns)

for i in range(len(active_guess_puzzle)):
    print board_grid_rows[i], active_guess_puzzle[i]

grid_dictionary = {
    'AW': active_guess_puzzle[0][0],
    'AX': active_guess_puzzle[1][0],
    'AY': active_guess_puzzle[2][0],
    'AZ': active_guess_puzzle[3][0],
    'BW': active_guess_puzzle[0][1],
    'BX': active_guess_puzzle[1][1],
    'BY': active_guess_puzzle[2][1],
    'BZ': active_guess_puzzle[3][1],
    'CW': active_guess_puzzle[0][2],
    'CX': active_guess_puzzle[1][2],
    'CY': active_guess_puzzle[2][2],
    'CZ': active_guess_puzzle[3][2],
    'DW': active_guess_puzzle[0][3],
    'DX': active_guess_puzzle[1][3],
    'DY': active_guess_puzzle[2][3],
    'DZ': active_guess_puzzle[3][3],
}


playing_game = True

while playing_game:
    # print COMPLETE_REFERENCE_PUZZLE
    # # print active_guess_puzzle
    # # print reference_check
    # # print complete_reference_check
    # # print flatten
    # # print ref_chk_chk
    # print ref_chk
    # print new_new
    if active_guess_puzzle == COMPLETE_REFERENCE_PUZZLE:
        print "You WON!!!!"
        break
    else:
        pass

    print
    print "Which cell would you like to edit?"
    guess_cell = raw_input()
    print
    if guess_cell in grid_dictionary:
        pass
    else:
        print "I'm sorry, I don't understand what cell you want to edit."
# do not allow items to be added to dictionary
# repeat question until valid key is selected

#    playing_game = False

    print "What do you want the value to be instead?"
    guess_value = raw_input()
    print

    grid_dictionary[guess_cell] = guess_value

    guess_row_1 = [grid_dictionary['AW'], grid_dictionary['BW'], grid_dictionary['CW'], grid_dictionary['DW']]
    guess_row_2 = [grid_dictionary['AX'], grid_dictionary['BX'], grid_dictionary['CX'], grid_dictionary['DX']]
    guess_row_3 = [grid_dictionary['AY'], grid_dictionary['BY'], grid_dictionary['CY'], grid_dictionary['DY']]
    guess_row_4 = [grid_dictionary['AZ'], grid_dictionary['BZ'], grid_dictionary['CZ'], grid_dictionary['DZ']]

    active_guess_puzzle = [guess_row_1, guess_row_2, guess_row_3, guess_row_4]

    print "  " + str(board_grid_columns)

    for i in range(len(active_guess_puzzle)):
        print board_grid_rows[i], active_guess_puzzle[i]
