# python sudoku_simple_outline.py

# print entirely blank board with grid reference titles / names of columns and rows

board_grid_columns = ['A', 'B', 'C', 'D']
board_grid_rows = ['W', 'X', 'Y', 'Z']
board_grid = board_grid_columns + board_grid_rows

print " " + str(board_grid_columns)

for item in board_grid_rows:
    print item

# COMPLETE_REFERENCE_PUZZLE = [complete_row_1[], complete_row_2[], complete_row_3[], complete_row_4[],
    # complete_row_5[], complete_row_6[], complete_row_7[], complete_row_8[],
    # complete_row_9[], complete_row_10[], complete_row_11[], complete_row_12[],
    # complete_row_13[], complete_row_14[], complete_row_15[], complete_row_16[]]


# 4x4 COMPLETE_REFERENCE_PUZZLE
complete_row_1 = ['1', '2', '3', '4']
complete_row_2 = ['3', '4', '2', '1']
complete_row_3 = ['2', '1', '4', '3']
complete_row_4 = ['4', '3', '1', '2']
COMPLETE_REFERENCE_PUZZLE = [complete_row_1, complete_row_2, complete_row_3, complete_row_4]
# emptySquares = ['x']

# for item in COMPLETE_REFERENCE_PUZZLE:
    # if item in emptySquares:
        # print .....

# Welcome User
# print "Welcome to Simple Sudoku!"
# print
# print "Here are the guidelines:"
# grid_length = len(COMPLETE_REFERENCE_PUZZLE)
# sqrt_1 = grid_length**(1/2.0)
# print "This sudoku puzzle is comprised of " + str(sqrt_1) + " rows and columns."

# for item in COMPLETE_REFERENCE_PUZZLE:
#     print item

guess_row_1 = ['1', '2', 'x', '4']
guess_row_2 = ['3', 'x', '2', 'x']
guess_row_3 = ['x', '1', '4', '3']
guess_row_4 = ['4', '3', 'x', '2']

COMPLETE_GUESS_PUZZLE = [guess_row_1, guess_row_2, guess_row_3, guess_row_4]

# # emptySquares = ['x']
guess_puzzle_4x4 = COMPLETE_GUESS_PUZZLE

## dictionary to allow user to select specific squares
grid_dictionary = {
    'AW': COMPLETE_GUESS_PUZZLE[0][0],
    'AX': COMPLETE_GUESS_PUZZLE[1][0],
    'AY': COMPLETE_GUESS_PUZZLE[2][0],
    'AZ': COMPLETE_GUESS_PUZZLE[3][0],
    'BW': COMPLETE_GUESS_PUZZLE[0][1],
    'BX': COMPLETE_GUESS_PUZZLE[1][1],
    'BY': COMPLETE_GUESS_PUZZLE[2][1],
    'BZ': COMPLETE_GUESS_PUZZLE[3][1],
    'CW': COMPLETE_GUESS_PUZZLE[0][2],
    'CX': COMPLETE_GUESS_PUZZLE[1][2],
    'CY': COMPLETE_GUESS_PUZZLE[2][2],
    'CZ': COMPLETE_GUESS_PUZZLE[3][2],
    'DW': COMPLETE_GUESS_PUZZLE[0][3],
    'DX': COMPLETE_GUESS_PUZZLE[1][3],
    'DY': COMPLETE_GUESS_PUZZLE[2][3],
    'DZ': COMPLETE_GUESS_PUZZLE[3][3],
}

print "Here is the puzzle:"
print
print "  " + str(board_grid_columns)

for i in range(len(COMPLETE_GUESS_PUZZLE)):
    print board_grid_rows[i], COMPLETE_GUESS_PUZZLE[i]




print "Which cell would you like to edit?"
guess_cell = raw_input()
print "Cell: ", guess_cell
print "What do you want the value to be instead?"
guess_value = raw_input()
print "Value: ", guess_value

grid_dictionary[guess_cell] = guess_value

guess_row_1 = [grid_dictionary['AW'], grid_dictionary['BW'], grid_dictionary['CW'], grid_dictionary['DW']]
guess_row_2 = [grid_dictionary['AX'], grid_dictionary['BX'], grid_dictionary['CX'], grid_dictionary['DX']]
guess_row_3 = [grid_dictionary['AY'], grid_dictionary['BY'], grid_dictionary['CY'], grid_dictionary['DY']]
guess_row_4 = [grid_dictionary['AZ'], grid_dictionary['BZ'], grid_dictionary['CZ'], grid_dictionary['DZ']]
COMPLETE_GUESS_PUZZLE = [guess_row_1, guess_row_2, guess_row_3, guess_row_4]

# # user_guess = guess_cell, guess_value

# # playing_game = True

# # while playing_game:
# #     user_guess = guess_cell + guess_value

# # print "  " + str(board_grid_columns)

for i in range(len(COMPLETE_GUESS_PUZZLE)):
    print board_grid_rows[i], COMPLETE_GUESS_PUZZLE[i]

    
