# coding=latin1

def print_instructions():
    """ Prints game instructions, which directions player can move
    and which directions and when the cars move"""
    
    print """
    Your movement options are:
    (A)head
    (B)ack
    (L)eft
    (R)ight
    """

def print_welcome():
    """ begin game - print welcome message """
    
    print
    print """Welcome to Frogger 0.5!
    
    You have 3 difficulty options:
    easy
    medium
    hard
    
    Which would you like to choose?
    """
    
def print_b(board, p_coords, c_coords):
    """Print the frogger gameboard, with player 'p' and car 'c'
    This will update the player's and cars' position on the game board
    input are board, which is a list of lists and coordinates, which are lists 
    of 2 ints and indexes the first int into board at index 0 and the second int 
    into board at index 1"""
    
    print
    
    # rows_in_board = range(board_length)
    # this creates a list of numbers 
    
    board[p_coords[0]][p_coords[1]] = '🐸'
    
    
    for key in c_coords:
        coord1 = c_coords[key][0]
        coord2 = c_coords[key][1]
        board[coord1][coord2] = '🚌'
        # coord1 = key[0]
        # coord2 = key[1]
        # board[coord1][coord2] = '🚌'

    # board[c_coords[0]][c_coords[1]] = '🚌'
    
    # board[p_coords[0]][p_coords[1]] = 'p '
    # board[c_coords[0]][c_coords[1]] = 'c '
    
    
    # for row in board:
    #     print "{} | {} {} | {}".format(row[0], row[1], row[2], row[3])
    #     # row[0] + " | " + row[1] + " " + row[2] + " | " + row[3]
    
    for row in board:
        print "{} | {} {} {} {} | {}".format(row[0], row[1], row[2], row[3], row[4], row[5])
        
    board[p_coords[0]][p_coords[1]] = '  '
    
    for key in c_coords:
        coord1 = c_coords[key][0]
        coord2 = c_coords[key][1]
        board[coord1][coord2] = '  '