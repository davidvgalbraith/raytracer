# coding=latin1

import os

from random import randint

import frog_print

import frogger_levels

from make_dict import make_coord_dict

from get_player_input import get_player_move

from random_move import move_cars

from spot_check import is_spot_taken

# from play_game_repl import repl_play_game

def check_move_valid(play_move):
    """Check user input to make sure chosen move is valid option"""
    move_options = 'ablrn'
    while play_move not in move_options:
        print "That is not a movement option. Please try again!\n"
        play_move = get_player_move()
    
    return play_move


def update_play_coords(p_move, p_coords):
    """Updates players coordinates """
    # while True:
    if p_move == 'a':
        p_coords[1] += 1
        
    elif p_move == 'b':
        p_coords[1] -= 1
        
    elif p_move == 'l':
        p_coords[0] -= 1
        # if p_coords[0] < max_index:
        #     p_coords[0] += max_index
        
    elif p_move == 'r':
        p_coords[0] += 1
        # if p_coords[0] > max_index:
        #     p_coords[0] -= max_index
        
    return p_coords
        
        
# def move_car(c_coords):
#     # """Moves car 1 position forward - returns car_new_coords"""
    
#     for key in c_coords:
#         i = randint(0, 1)
#         num_spaces = randint(0,1)
#         c_coords[key][i] += num_spaces
    
#     return c_coords


def check_for_win(player_coords, winning_coord):
    """Checks if player made it to opposite side of gameboard
    if players coords and car coords aren't the same, this function will
    check if players coord at index 0 is 3 and if yes, player wins
    if no, the game continues looping - car moves"""
    
    
    if player_coords[1] == winning_coord:
        print 'You win!!!'
        winner = 'win'
    
    else:
        winner = None
        
    return winner
    
def repl_play_game(board, play_coords):
    print """
        
    Would you like to play again? Y/N?
        
    """
    
    keep_playing = raw_input('> ').lower().strip()
    
    while True:
        if keep_playing.startswith('y', 0, 1):
            play_game(board, play_coords)
        elif keep_playing.startswith('n', 0, 1):
            return False
        else:
            print "WHY MUST YOU MAKE THIS SO DIFFICULT?!"
            keep_playing = raw_input("Try again\n > ")


def play_game(board, play_coords):
    """This should be a REPL - loop thru game conditions
    arguments are game board and coordinates dictionary contains
    player's and cars' coordinates"""
    
    row_0 = ['  ','  ','  ','  ', '  ','  ']
    row_1 = ['  ','  ','  ','  ', '  ','  ']
    row_2 = ['  ','  ','  ','  ', '  ','  ']
    row_3 = ['  ','  ','  ','  ', '  ','  ']
    row_4 = ['  ','  ','  ','  ', '  ','  ']
    row_5 = ['  ','  ','  ','  ', '  ','  ']
    row_6 = ['  ','  ','  ','  ', '  ','  ']
    row_7 = ['  ','  ','  ','  ', '  ','  ']
    row_8 = ['  ','  ','  ','  ', '  ','  ']
    row_9 = ['  ','  ','  ','  ', '  ','  ']
    row_10 = ['  ','  ','  ','  ', '  ','  ']

    winning_coord = len(row_0) - 1

    b = [row_0, row_1, row_2, row_3, row_4, row_5, row_6, row_7, row_8, row_9, row_10]

    max_board_index = len(b) - 1

    p_coord0 = randint(0, max_board_index)

    play_coords = [p_coord0, 0]
    
    frog_print.print_welcome()
    
    level = frogger_levels.choose_how_difficult()
    
    car_coords = frogger_levels.make_coord_dict(level, winning_coord)
    
    while True:
        frog_print.print_instructions()
        #print instructions
        
        frog_print.print_b(board, play_coords, car_coords)
        #print game board
        
        player_move = get_player_move()
        #ask player which direction to move
        
        check_move_valid(player_move)
        #checks to make sure player chose a valid movement option
        
        p_new_coords = update_play_coords(player_move, play_coords)
        #calculates players coordinates
        # while p_new_coords == True
        
        
        lose = is_spot_taken(p_new_coords, car_coords)
        #checks if player and car occupy same spot
        if lose == True:
            frog_print.print_b(board,play_coords, car_coords)
            # play_again = repl_play_game()
            break
        
        car_new_coords = move_cars(car_coords, board)
        
        lose = is_spot_taken(p_new_coords, car_new_coords)
        #checks if player and car occupy same spot
        if lose == True:
            frog_print.print_b(board,play_coords, car_coords)
            break
        
        winner = check_for_win(p_new_coords, winning_coord)
        #checks if player made it to opposite side of gameboard
        if winner == 'win':
            frog_print.print_b(board, play_coords, car_coords)
            break
        
        os.system('clear')
        
    
    repl_play_game(board, play_coords)
    
    

    



row_0 = ['  ','  ','  ','  ', '  ','  ']
row_1 = ['  ','  ','  ','  ', '  ','  ']
row_2 = ['  ','  ','  ','  ', '  ','  ']
row_3 = ['  ','  ','  ','  ', '  ','  ']
row_4 = ['  ','  ','  ','  ', '  ','  ']
row_5 = ['  ','  ','  ','  ', '  ','  ']
row_6 = ['  ','  ','  ','  ', '  ','  ']
row_7 = ['  ','  ','  ','  ', '  ','  ']
row_8 = ['  ','  ','  ','  ', '  ','  ']
row_9 = ['  ','  ','  ','  ', '  ','  ']
row_10 = ['  ','  ','  ','  ', '  ','  ']

winning_coord = len(row_0) - 1

b = [row_0, row_1, row_2, row_3, row_4, row_5, row_6, row_7, row_8, row_9, row_10]

max_board_index = len(b) - 1

p_coord0 = randint(0, max_board_index)

play_coords = [p_coord0, 0]

# car_coords = [0, 1]

# car_coord_dict = {'c1' : [0, 1], 'c2' : [2, 2]}

play_game(b, play_coords)