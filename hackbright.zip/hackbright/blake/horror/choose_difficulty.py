# coding=latin1

from random import randint, randrange

def choose_how_difficult():
    
    difficulty = raw_input('> ').lower()
    diff_options = ['easy', 'medium', 'hard']
    
    while difficulty not in diff_options:
        print "Try again."
        difficulty = raw_input('> ').lower()

    if difficulty == 'easy':
        return 1
        
    elif difficulty == 'medium':
        return 2
        
    else:
        return 3



def row_size(x):
    row = []
    for item in range(x):
        row.append('  ')
    return row
    
def board_size(x, row):
    board = []
    for item in range(x):
        board.append(row)
    
    return board
    
# row = row_size(5)

# board = board_size(5, row)

# def print_da_board(row, board):
#     """Print the frogger gameboard, with player 'p' and car 'c'
#     This will update the player's and cars' position on the game board
#     input are board, which is a list of lists and coordinates, which are lists 
#     of 2 ints and indexes the first int into board at index 0 and the second int 
#     into board at index 1"""
    
#     # row = list
#     # board = list of rows
#     string = ''

#     for row in board:
#         print "{} | {} {} {} | {}".format(row[0], row[1], row[2], row[3], row(4))


#         # top_index = len(row) - 1
        # for item in row:
        #     if item == row[0]:
        #         string = "{} | ".format(item)
        #     elif item == row[1:top_index-1]:
        #         string = string + '{} '.format(item)
        #     else:
        #         string = string + '| {}'.format(item)
        # return string


        # for item in row:
        #     length = len(row)
        #     if item == row[0]:
        #         print "{} | ".format(item)
        #     elif item == row[1:(length-2)]:
        #         print "{} ".format(item)
        #     else:
        #         print "| {}".format(item)
        #     # print "{} | {} {} | {}".format(row[0], row[1], row[2], row[3])
            
            
def print_b(board, p_coords, c_coords):
    """Print the frogger gameboard, with player 'p' and car 'c'
    This will update the player's and cars' position on the game board
    input are board, which is a list of lists and coordinates, which are lists 
    of 2 ints and indexes the first int into board at index 0 and the second int 
    into board at index 1"""
    
    print
    
    # rows_in_board = range(board_length)
    # this creates a list of numbers 
    
    board[p_coords[0]][p_coords[1]] = '🐸'
    
    
    for key in c_coords:
        coord1 = c_coords[key][0]
        coord2 = c_coords[key][1]
        board[coord1][coord2] = '🚌'
        # coord1 = key[0]
        # coord2 = key[1]
        # board[coord1][coord2] = '🚌'

    # board[c_coords[0]][c_coords[1]] = '🚌'
    
    # board[p_coords[0]][p_coords[1]] = 'p '
    # board[c_coords[0]][c_coords[1]] = 'c '
    
    
    # for row in board:
    #     print "{} | {} {} | {}".format(row[0], row[1], row[2], row[3])
    #     # row[0] + " | " + row[1] + " " + row[2] + " | " + row[3]
    
    for row in board:
        print "{} | {} {} {} {} | {}".format(row[0], row[1], row[2], row[3], row[4], row[5])
        
    board[p_coords[0]][p_coords[1]] = '  '
    
    for key in c_coords:
        coord1 = c_coords[key][0]
        coord2 = c_coords[key][1]
        board[coord1][coord2] = '  '


# row = []
# for item in range(5):
#     row.append('  ')

# choice = choose_how_difficult()

# coord_dict = make_coord_dict(choice)

# play_coords = [2, 0]