
def draw_gameboard(board):
    # print (' |    ' + board[0:4] + '    | ')
    # print (' |    ' + board[4:8] + '    | ')
    # print (' |    ' + board[8:12] + '    | ')
    # print (' |    ' + board[12:16] + '    | ')
    # print (' |    ' + board[16:20] + '    | ')
    # print (' |    ' + board[20:24] + '    | ')
    # print (' |    ' + board[24:28] + '    | ')
    # # print (' |    | ')
    # print (' |    | ')
    # print  (' ' + board[0] + ' | ' + board[1] + ' | ' + board[2])
    # print (' |    | ')
    
# draw_gameboard(['', '', '', '', '', '', '', '', ''])
