def make_list(x, row = []):
    """This function makes a formatted list for a row in our board"""
    
    list_range = range(x)
    # if x = 5, list_range = [0, 1, 2, 3, 4]
    
    # row = []
    
    for item in list_range:
        item = '    '
        row.append(item)
    return row

row = make_list(5)