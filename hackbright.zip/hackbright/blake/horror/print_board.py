# coding=latin1

emoji_1 = '🐸'

emoji_2 = '🚗'
    
# emoji_length = len('🚗')


def print_b(board, p_coords, c_coords):
    """Print the frogger gameboard, with player 'p' and car 'c'
    This will update the player's and cars' position on the game board
    input are board, which is a list of lists and coordinates, which are lists 
    of 2 ints and indexes the first int into board at index 0 and the second int 
    into board at index 1"""
    
    print
    
    # rows_in_board = range(board_length)
    # this creates a list of numbers 
    
    board[p_coords[0]][p_coords[1]] = '🐸'
    
    
    for key in c_coords:
        coord1 = c_coords[key][0]
        coord2 = c_coords[key][1]
        board[coord1][coord2] = '🚌'
        # coord1 = key[0]
        # coord2 = key[1]
        # board[coord1][coord2] = '🚌'

    # board[c_coords[0]][c_coords[1]] = '🚌'
    
    # board[p_coords[0]][p_coords[1]] = 'p '
    # board[c_coords[0]][c_coords[1]] = 'c '
    
    
    for row in board:
        print "{} | {} {} | {}".format(row[0], row[1], row[2], row[3])
        # row[0] + " | " + row[1] + " " + row[2] + " | " + row[3]
        # print "  |     |"
        
    board[p_coords[0]][p_coords[1]] = '  '
    
    for key in c_coords:
        coord1 = c_coords[key][0]
        coord2 = c_coords[key][1]
        board[coord1][coord2] = '  '





row_0 = ['  ','  ','  ','  ', '  ']
row_1 = ['  ','  ','  ','  ', '  ']
row_2 = ['  ','  ','  ','  ', '  ']
row_3 = ['  ','  ','  ','  ', '  ']
row_4 = ['  ','  ','  ','  ', '  ']
row_5 = ['  ','  ','  ','  ', '  ']
row_6 = ['  ','  ','  ','  ', '  ']
row_7 = ['  ','  ','  ','  ', '  ']
row_8 = ['  ','  ','  ','  ', '  ']
row_9 = ['  ','  ','  ','  ', '  ']

b = [row_0, row_1, row_2, row_3, row_4, row_5, row_6, row_7, row_8, row_9]










# board_length = 5
# range board length is a list of integers
# board is list 

# # want to make the board length bigger, maybe use range function see below
# for num in range(board_length):
    
#     board.append('    ','    ','    ','    ','    ', '    ')


""" Want to make a for loop to print the board but having trouble figuring out how to do it properly
use range to create a list of numbers, then use that list of numbers to make a list within list for the board
want to be able to index the board to insert player and car positions/coordinates
don't think I need to use .format or a variable... think I can just make a row list, appened available spot 
to that list and then append that list to the board list"""

# for row in range(board_length):
#     if row == 0:
        
#         avail_spot = '{} | '.format
#         spot = '{} | '.format(row[index])
    #     elif 0 < index < (board_length - 1):
    #         index = '{} '.format(row[index])
    #     elif item == (board_length - 1):
    #         item = '| {}'.format(row[item])
    #     else:
    #         break
    #     row.append(item)
    # board.append(row)

            

    # # item = ['  '] * board_length
    # item = '{} | {} {} {} | {}'.format(item[0], item[1], item[2], item[3], item[4])
    # board.append(item)
    # # print 
    #     # print "{} | {} {} | {}".format(row[item]

# board_length = len(row)

# board = [row, row, row, row]

# board_range = range(board_length)





# maybe use dictionaries to save players & cars coordinates
# that way you can look up index of 'p' and store that to a variable
# and dictionaries are mutable... right?

play_coords = [2, 0]
car_coords = [0, 1]

# print_b(b, play_coords, car_coords)