# row_1 = ["1","2","3"]
# row_2 = ["4","5","6"]
# row_3 = ["7","8","9"]
# b = [row_1, row_2, row_3]

# def printb(board):
#     print
#     print " " + board[0][0] + " | " + board[0][1] + " | " + board[0][2] + " "
#     print "---+---+---"
#     print " " + board[1][0] + " | " + board[1][1] + " | " + board[1][2] + " "
#     print "---+---+---"
#     print " " + board[2][0] + " | " + board[2][1] + " | " + board[2][2] + " "
#     print

# printb(b)
# b[0][0] = "x"
# b[2][1] = "o"
# printb(b)

row_1 = ['1','2','3','4']
row_2 = ['1','2','3','4']
row_3 = ['1','2','3','4']
row_4 = ['1','2','3','4']
b = [row_1, row_2, row_3, row_4]

def printb(board):
    print
    print board[0][0] + " | " + board[0][1] + " " + board[0][2] + " | " + board[0][3]
    print "  |     |"
    print board[1][0] + " | " + board[1][1] + " " + board[1][2] + " | " + board[1][3]
    print "  |     |"
    print board[2][0] + " | " + board[2][1] + " " + board[2][2] + " | " + board[2][3]
    print "  |     |"
    print board[3][0] + " | " + board[3][1] + " " + board[3][2] + " | " + board[3][3]
    print "  |     |"
    print
    
printb(b)
b[2][0] = 'p'
b[0][1] = 'c'
printb(b)