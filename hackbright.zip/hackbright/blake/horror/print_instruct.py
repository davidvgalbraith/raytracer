def print_instructions():
    """ Prints game instructions, which directions player can move
    and which directions and when the cars move"""
    
    print "Your movement options are:"
    print "(A)head"
    print "(B)ack"
    print "(L)eft"
    print "(R)ight"
    print

def print_welcome():
    """ begin game - print welcome message """
    
    print
    print "Welcome to Frogger 0.5!"
    print
    print """You have 3 difficulty options:
    easy
    medium
    hard
    
    Which would you like to choose?
    """