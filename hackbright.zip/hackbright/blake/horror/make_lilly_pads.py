row_0 = ['  ','  ','  ','  ', '  ','  ']

row = []

for item in range(5):
    row.append('  '):

print row