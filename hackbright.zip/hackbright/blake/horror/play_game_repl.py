from frogger import play_game

def repl_play_game(board, play_coords):
    print """
        
    Would you like to play again? Y/N?
        
    """
    
    keep_playing = raw_input('> ').lower().strip()
    
    while keep_playing == 'y':
        play_game(board, play_coords)
    # elif keep_playing == 'n':
    #     return False



# def repl_play_game(user_input, board, play_coords):
#     while :
#         play_game(board, play_coords)
    
    # while keep_playing == 'y':
        
    #     frogger.play_game(board, play_coords)

        # keep_playing = raw_input('> ').lower().strip()
        
        # if keep_playing == 'y':
        #     return True
            
        # elif keep_playing == 'n':
        #     return False
        
        # else:
        #     print "That is not a valid answer! Please try again"
            
    # play_game(board, play_coords)