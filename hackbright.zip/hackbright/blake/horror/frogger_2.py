# coding=latin1

import frog_print


def play_game(board, play_coords, car_coords):
    """This should be a REPL - loop thru game conditions
    arguments are game board and coordinates dictionary contains
    player's and cars' coordinates"""
    
    frog_print.print_welcome()
    
    level = choose
    
        
        print_board.print_b(board, play_coords, car_coords)
        #print game board
        
        level = choose_difficultly.choose_how_difficult()
        
        car_coords = choose_difficulty.make_coord_dict(level)
        
        print_instructions()
        #print instructions
        
        player_move = get_player_move()
        #ask player which direction to move
        
        check_move_valid(player_move)
        #checks to make sure player chose a valid movement option
        
        p_new_coords = update_play_coords(player_move, play_coords)
        #calculates players coordinates
        # while p_new_coords == True
        
        
        lose = check_for_free_spot(p_new_coords, car_coords)
        #checks if player and car occupy same spot
        if lose == 'lose':
            break
        
        # update_game_board(board, p_new_coords, car_coords)
        # print_board(board, play_coords, car_coords)
        car_new_coords = move_car(car_coords)
        
        lose = check_for_free_spot(p_new_coords, car_new_coords)
        #checks if player and car occupy same spot
        if lose == 'lose':
            break
        
        # update_game_board(board, p_new_coords, car_coords)

        winner = check_for_win(p_new_coords)
        #checks if player made it to opposite side of gameboard
        if winner == 'win':
            print_board.print_b(board, play_coords, car_coords)
            break
