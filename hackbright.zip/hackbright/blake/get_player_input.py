def get_player_move():
    """Ask player which direction to move & calc new coordinates"""
    
    print 'Which direction would you like to move?'
    print
    
    play_move = raw_input('> ').lower()
    
    return play_move