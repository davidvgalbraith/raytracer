from random import randint

def move_cars(car_coord_dict, board):
    """ function that moves cars forward 0, 1, or 2 spaces
    if car is at end of board, it moves car back to the beginning of board"""
    
    max_index = len(board) - 1
    
    for key in car_coord_dict:
        spaces = randint(0, 1)
        car_coord_dict[key][0] += spaces
        if car_coord_dict[key][0] > max_index:
            car_coord_dict[key][0] -= max_index
    
    return car_coord_dict