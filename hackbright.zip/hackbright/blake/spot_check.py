def is_spot_taken(p_coords, coord_dict):
    """ Checks to see if players spot is already occupied by car
    input is players coords as list and car coords in dict
    returns string if spot is occupied and none if spot is vacant"""
    
    # if p_coords in coord_dict:
    #     loser = True
    # else:
    #     loser = False
    
    # return loser

    for key in coord_dict:
        if p_coords == coord_dict[key]:
            loser = True
            print "Spot occupied :( you lose"
            break
        else:
            loser = False

    return loser


play_coords = [2, 0]

car_coords = {'c': [1, 1], 'b': [2, 2]}

answer = is_spot_taken(play_coords, car_coords)
