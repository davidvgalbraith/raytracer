from random import randint

def make_coord_dict(x):
    """makes a dictionary containing x keys with list values of 2 ints"""
    
    car_coord_dict = {}
    
    num_cars = range(0, x)
    
    for car in num_cars:
        index1 = randint(1, 3)
        car_coord_dict[car] = [0, index1]
    
    return car_coord_dict