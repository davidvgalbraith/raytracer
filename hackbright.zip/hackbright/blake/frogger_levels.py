from random import randint

def choose_how_difficult():
    
    difficulty = raw_input('> ').lower().strip()
    diff_options = ['easy', 'medium', 'hard']
    
    while difficulty not in diff_options:
        print "Try again."
        difficulty = raw_input('> ').lower().strip()

    if difficulty == 'easy':
        return 2
        
    elif difficulty == 'medium':
        return 3
        
    else:
        return 4


def make_coord_dict(x, winning_coord):
    """makes a dictionary containing x keys with list values of 2 ints"""
    
    car_coord_dict = {}
    
    num_cars = range(0, x)
    
    max_index1 = winning_coord - 1
    
    i = 1
    
    for car in range(0, x):
        car = num_cars[car]
        index0 = randint(0, 4)
        car_coord_dict[car] = [index0, i]
        i += 1

    return car_coord_dict
