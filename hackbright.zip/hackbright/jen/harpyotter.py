#Provide player with instructions to play the game

import random
import textwrap

INSTRUCTIONS = textwrap.dedent("""
    Welcome to today's quidditch match!

    You'll be playing as the seeker, so it's your job to catch the snitch.
    Select the best course of action throughout the game
    until either you or the opposing team's seeker catches the snitch.
    If you catch it before the other team's seeker,
    your team will earn 150 points and win the match!
    """)

GRYFFINDOR = "Gryffindor"
SLYTHERIN = "Slytherin"
HUFFLEPUFF = "Hufflepuff"
RAVENCLAW = "Ravenclaw"
TEAMS = [GRYFFINDOR, HUFFLEPUFF, RAVENCLAW, SLYTHERIN]

def keep_playing(next):
    """Asks player to keep game going to trigger next scenario."""
    print textwrap.dedent("""

    Type 'fly' to continue.
    """)

    while True:
        next = raw_input("> ").lower()
        if next != "fly":
            print textwrap.dedent("""
            Invalid response.
            Type 'fly' to continue.
            """)
        else:
            break

def increase_score_10(team, scores):
    """Increases a team's score by 10"""
    scores[team] += 10

def increase_score_150(team, scores):
    """Increases a team's score by 150 when they catch the snitch"""
    scores[team] += 150

def print_scores(scores, player_team, opposing_team):
    """Prints scores of both teams"""
    print "The current score is: "
    print "{}: ".format(player_team), scores[player_team]
    print "{}: ".format(opposing_team), scores[opposing_team]

def print_final_score(scores, player_team, opposing_team):
    """Prints final score"""
    print "Final score is: "
    print "{}: ".format(player_team), scores[player_team]
    print "{}: ".format(opposing_team), scores[opposing_team]
    print

    if scores[player_team] > scores[opposing_team]:
        print "CONGRATULATIONS! {} wins the match! Go {}!".format(player_team, player_team)
    elif scores[player_team] < scores[opposing_team]:
        print "{} wins the match!".format(opposing_team)
    else:
        print "It's a tie!"

def get_valid_user_input(valid_choices):
    while True:
        choice = raw_input("> ")
        choice = choice.upper()
        if choice in valid_choices:
            return choice
        else:
            print "Invalid response. Select again."

def select_player_team():
    """Asks player to select a team to play on"""

    print textwrap.dedent("""
    Which team would you like to play for?

    (G)ryffindor
    (H)ufflepuff
    (R)avenclaw
    (S)lytherin

    """)
    choice = get_valid_user_input(["G", "H", "R", "S"])
    if choice == "G":
        player_team = GRYFFINDOR
    elif choice == "H":
        player_team = HUFFLEPUFF
    elif choice == "R":
        player_team = RAVENCLAW
    elif choice == "S":
        player_team = SLYTHERIN
    return player_team

def print_welcome_to_team(player_team):
    print textwrap.dedent("""
    Welcome to the {} quidditch team!
    """.format(player_team))
    return player_team

def select_opposing_team(player_team):
    """Randomly selects the opposing team from the other three teams."""

    new_teams = TEAMS[:]
    new_teams.remove(player_team)
    return random.choice(new_teams)

def print_match_name(player_team, opposing_team):

    print textwrap.dedent("""
    Today's match is {} vs. {}!
    """.format(player_team, opposing_team))

def ask_ready_to_play():
    print textwrap.dedent("""
    Are you ready to play?
    (Y)es, I'm ready!
    (N)o, I'm not ready...it's too much pressure!
    """)
    return get_valid_user_input(["Y", "N"])

def start_scenario_1(scores, player_team, opposing_team):
    """Starts scenario 1 (player's team scored 10 points) and gives player options"""

    print textwrap.dedent("""
    Wow! The {} chasers already scored 10 points. What do you do?

    (A) Take a moment to stop, celebrate, and cheer on your teammates!
    (B) Keep moving. You have to focus on finding the snitch.

    """.format(player_team))
    increase_score_10(player_team, scores)
    choice = get_valid_user_input(["A", "B"])

    if choice == "A":
        print textwrap.dedent("""
        Go {}! You got a thumbs up from your teammate across the way.
        """.format(player_team))
        print
        print_scores(scores, player_team, opposing_team)
        print

    elif choice == "B":
        print
        print textwrap.dedent("Good idea. You can always celebrate after {} wins.".format(player_team))
        print
        print_scores(scores, player_team, opposing_team)

def start_scenario_2(scores, player_team, opposing_team):
    """Starts scenario 2 (bludger approaching) and gives player options"""

    print textwrap.dedent("""
    UH OH. There's a bludger coming your way! What should you do to try and avoid it?

    (A) Stop abrubtly.
    (B) Accelerate.
    (C) Dart to the left.
    (D) Do a barrel roll.

    """)
    choice = get_valid_user_input(["A", "B", "C", "D"])

    if choice == "A":
        import random
        print
        bludger_outcome = ["""BOOM! You've been hit by the bludger and knocked off your broom!
        ...you can always go to the hospital wing later. You get back on your broom and are ready to find that snitch.""",
        "You've been hit by the bludger and lost your balance. As you were falling off your broom, you were lucky to grab it in time to hang on by one hand!"]

        print(random.choice(bludger_outcome))


    elif choice == "B":
        print "Nice work! That bludger is eating your dust. Oh, and {} scored another goal!".format(player_team)
        print
        increase_score_10(player_team, scores)
        print_scores(scores, player_team, opposing_team)

        # print "Type 'fly' to continue."
        # next = raw_input("> ")
        # next = next.lower( )


    elif choice == "C":
        print textwrap.dedent("""
        *%$!...what happened?
        ...
        ...
        ...
        ... You feel your head throbbing and slowly realize the bludger still managed to hit you in the back of the head.\
        Also, while you were hit, the {} chasers scored a goal.
        """.format(opposing_team))
        increase_score_10(opposing_team, scores)
        print_scores(scores, player_team, opposing_team)

    elif choice == "D":
        print textwrap.dedent("""
        Phew...the bludger just missed you by an inch.

        """)

def start_scenario_3(scores, player_team, opposing_team):
    """Starts scenario 3 (Opposing team's seeker flying towards something) and gives player options"""

    print textwrap.dedent("""
    Looks like the {} seeker is onto something...
    they're flying very quickly towards something on the north end of the field. What should you do?

    (A) Go after them!
    (B) You don't believe they actually see the snitch. Keep flying around to see if you can find it.

    """.format(opposing_team))
    choice = get_valid_user_input(["A", "B"])

    snitch_outcome = ["It turns out the {} seeker was following the snitch...".format(opposing_team), "Lucky that you didn't follow {}'s seeker. You see the snitch on the south side of the field and go after it!".format(opposing_team)]

    if choice == "A":
        print textwrap.dedent("""
        Nice! You caught up to the {} seeker just as they were 2 brooms length away from the snitch.

        What now!? Do you...

        (A) Try to prevent the {} seeker from getting the snitch by grabbing the end of their broom.
        (B) Try to fly past the seeker and catch the snitch before they do.
        """.format(opposing_team, opposing_team))
        choice = get_valid_user_input(["A", "B"])


        if choice == "A":
            print textwrap.dedent("Phew, Madam Hooch didn't see you commit that foul, but the snitch just disappeared and {} scored a goal.".format(opposing_team))
            print
            increase_score_10(opposing_team, scores)
            print_scores(scores, player_team, opposing_team)


        elif choice == "B":
            print textwrap.dedent("Hooray! You've caught the snitch! {} is awarded 150 points!".format(player_team))

            print '''


                                                                     ^
                                                                 .*///
                                                             .*/////.
                                                        .*/////////.
                                                   .*/////////.
                                                 .*//////*
                                                /////*
                                              .**^
                                       dDDDDDDb
                                ...--dDDDDDDDDDb
                          *\\\\\\\\\\\\\\. dDDDDDDDDDDDb
                  ... *\\\\\\\\\\\\\\\\\\\\.  dDDDDDDDDDDb
           ~~~\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*      dDDDDDDDDb
        ^***                           dDDDDb


            '''


            increase_score_150(player_team, scores)
            print_final_score(scores, player_team, opposing_team)

    elif choice == "B":
        print random.choice(snitch_outcome)
        result = random.choice(snitch_outcome)

        if result == snitch_outcome[0]:
            print textwrap.dedent("""
            You can't let {} win this match! You...
            (A) Fly straight for the snitch at full speed.
            (B) Fly straight towards the {} seeker and play chicken to try to get them to fly off course.
            """.format(opposing_team, opposing_team))
            choice = get_valid_user_input(["A", "B"])

            if choice == "A":
                print textwrap.dedent("Wow, your broom is fast! You got to the snitch seconds before the {} seeker could and caught the snitch! {} is awarded 150 points.".format(opposing_team, player_team))

                print '''


                                                                     ^
                                                                 .*///
                                                             .*/////.
                                                        .*/////////.
                                                   .*/////////.
                                                 .*//////*
                                                /////*
                                              .**^
                                       dDDDDDDb
                                ...--dDDDDDDDDDb
                          *\\\\\\\\\\\\\\. dDDDDDDDDDDDb
                  ... *\\\\\\\\\\\\\\\\\\\\.  dDDDDDDDDDDb
           ~~~\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*      dDDDDDDDDb
        ^***                           dDDDDb


            '''


                increase_score_150(player_team, scores)
                print_final_score(scores, player_team, opposing_team)

            elif choice == "B":
                print textwrap.dedent("The {} seeker saw you coming, but didn't even flinch. They were able to catch the snitch anyway. {} is awarded 150 points.".format(opposing_team, opposing_team))
                increase_score_150(opposing_team, scores)
                print_final_score(scores, player_team, opposing_team)


        elif result == snitch_outcome[1]:
            print textwrap.dedent("""
            Oh - it looks like you caught the attention of the {} seeker. To avoid them catching the snitch first you...
            (A) Fly straight for the snitch - you know you can get it!
            (B) Take a detour to throw the {} seeker off.
            """.format(opposing_team, opposing_team))
            choice = get_valid_user_input(["A", "B"])

            if choice == "A":
                print textwrap.dedent("Wow, your broom is fast! You got to the snitch seconds before the {} seeker could and caught the snitch! {} is awarded 150 points.".format(opposing_team, player_team))

                print '''


                                                                     ^
                                                                 .*///
                                                             .*/////.
                                                        .*/////////.
                                                   .*/////////.
                                                 .*//////*
                                                /////*
                                              .**^
                                       dDDDDDDb
                                ...--dDDDDDDDDDb
                          *\\\\\\\\\\\\\\. dDDDDDDDDDDDb
                  ... *\\\\\\\\\\\\\\\\\\\\.  dDDDDDDDDDDb
           ~~~\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*      dDDDDDDDDb
        ^***                           dDDDDb


            '''

                increase_score_150(player_team, scores)
                print_final_score(scores, player_team, opposing_team)

            elif choice == "B":
                print textwrap.dedent("Good, you threw the {} seeker off, but now you also lost track of the snitch. ".format(opposing_team))

def start_scenario_4(scores, player_team, opposing_team):
    """Starts scenario 4 (something shiny ahead) and gives player options"""

    print textwrap.dedent("""
        There's something shiny on the corner of the field. Could it be the snitch? What's your move?

        (A) Fly at full speed towards the shiny dot on the field to see if it's the snitch.
        (B) Fly slowly towards it so you don't catch the other seeker's attention.

        """)
    choice = get_valid_user_input(["A", "B"])


    if choice == "A":
        increase_score_150(player_team, scores)
        print textwrap.dedent("""
        It IS the snitch! And you've caught it!

        {} is awarded 150 points!

        print '''


                                                                     ^
                                                                 .*///
                                                             .*/////.
                                                        .*/////////.
                                                   .*/////////.
                                                 .*//////*
                                                /////*
                                              .**^
                                       dDDDDDDb
                                ...--dDDDDDDDDDb
                          *\\\\\\\\\\\\\\. dDDDDDDDDDDDb
                  ... *\\\\\\\\\\\\\\\\\\\\.  dDDDDDDDDDDb
           ~~~\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\*      dDDDDDDDDb
        ^***                           dDDDDb


            '''

        """.format(player_team))
        print_final_score(scores, player_team, opposing_team)

    elif choice == "B":
        increase_score_150(opposing_team, scores)
        print textwrap.dedent("""
        Too late, the {} seeker spotted it too and got to it first!

        {} is awarded 150 points.

        """.format(opposing_team, opposing_team))
        print_final_score(scores, player_team, opposing_team)


def start_game():
    """Starts the match"""

    print INSTRUCTIONS
    player_team = select_player_team()
    opposing_team = select_opposing_team(player_team)
    scores = {player_team:0, opposing_team:0}

    print_match_name(player_team, opposing_team)
    choice = ask_ready_to_play()

    #player says (Y)es to playing
    if choice == "Y":

        print textwrap.dedent("""

        Oh, that's the whistle! The quaffle was released and the game has begun!
        """)

        keep_playing(next)
        start_scenario_1(scores, player_team, opposing_team)
        keep_playing(next)
        start_scenario_2(scores, player_team, opposing_team)
        keep_playing(next)
        start_scenario_3(scores, player_team, opposing_team)
        if scores[player_team] >= 150 or scores[opposing_team] >= 150:
            return
        keep_playing(next)

        #If game is not yet won, play scenario 4
        if scores[player_team] < 150 and scores[opposing_team] < 150:
            start_scenario_4(scores, player_team, opposing_team)


    #player says (N)o to playing
    elif choice == "N":
        print textwrap.dedent("""

        Oh, that's too bad. {} forfeits and {} wins.

        """.format(player_team, opposing_team))



start_game()


            
