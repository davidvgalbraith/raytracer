import os

def make_move(board, player):
	"""Asks a player for a move and adds the move to the board."""
	player_piece = ["x", "o"]

	# asks user for their player #


	# asks user for a row
	move = raw_input("Player {}, please enter your move in the form of a number with row first, column second with a space in between:\n>".format(player + 1))

	row, column = move.strip().split(" ")

	# asks user for a column


	# check if board at row and column has been taken, else put x or o there depending on player

	#googled how to do multi-line conditionals

	while check_input(row, column, board):
		move = raw_input("Please enter row and column again:\n>")
		row, column = move.strip().split(" ")
	board[int(row) - 1][int(column) - 1] = player_piece[player]


def check_input(row, column, board):
	if not row.isdigit() or not column.isdigit():
		print "One of your values is not a number!"
	elif  int(row) < 1 or int(row) > 3:
		print "Please enter a row number between 1 and 3!"
	elif int(column) < 1 or int(column) > 3:
		print "Please enter a column number between 1 and 3!"
	elif board[int(row) - 1][int(column) - 1] != " ":
		print "To error is human...this space has been taken!"
	else:
		return False
	return True



def print_board(board):
	"""Prints board to show the players"""

	print
	print " " + board[0][0] + " " +"|" + " " + board[0][1] + " " +"|" + " " + board[0][2] + " "
	print "---+---+---"
	print " " + board[1][0] + " " +"|" + " " + board[1][1] + " " +"|" + " " + board[1][2] + " "
	print "---+---+---"
	print " " + board[2][0] + " " +"|" + " " + board[2][1] + " " +"|" + " " + board[2][2] + " "
	print



def check_win(board):
	"""Checks board for a winner and returns winner"""
	# Find mistke here (clue, at the end)
	# checks rows for win

	if board[0][0] == board[0][1] == board[0][2] and board[0][0] != " ":
		return True
	if board[1][0] == board[1][1] == board[1][2] and board[1][0] != " ":
		return True
	if board[2][0] == board[2][1] == board[2][2] and board[2][0] != " ":
		return True

	# checks columns for win
	if board[0][0] == board[1][0] == board[2][0] and board[0][0] != " ":
		return True
	if board[0][1] == board[1][1] == board[2][1] and board[0][1] != " ":
		return True
	if board[0][2] == board[1][2] == board[2][2] and board[0][2] != " ":
		return True

	# checks diagonals for win
	if board[0][0] == board[1][1] == board[2][2] and board[0][0] != " ":
		return True
	if board[2][2] == board[1][1] == board[0][0] and board[2][2] != " ":
		return True

	return False

def check_for_full(board):
	"""Checks if board is full"""
	for row in board:
		for cell in row:
			if cell == " ":
				return False
	return True

def play(board):
	"""Main REPL function to play the game"""

	print "Let's play tic tac toe!"

	player = 0

	os.system('clear')
	print_board(board)

	while True:
		# make some moves
		make_move(board, player)


		#Print the board now that moves have been made
		os.system('clear')
		print_board(board)

		#check for win first
		if check_win(board):
			print "Player {} is the winner!".format(player + 1)
			break

		#check for tie
		if check_for_full(board):
			print "Wah-wah..."
			print "It's a tie!"
			break
		#Check if win or tie condition met

		#Switch Player
		player = (player + 1)%2


#################################################################################
tic_tac_toe_board = [[" "," "," "],[" "," "," "],[" "," "," "]]
# print_board(tic_tac_toe_board)

print """
"""


play(tic_tac_toe_board)


# tic_tac_toe_board = [["x","o","o"],["x","o","x"],["x","x","o"]]
# print_board(tic_tac_toe_board)
# print check_win(tic_tac_toe_board)
# tic_tac_toe_board = [[" "," "," "],[" "," "," "],[" "," "," "]]
# print_board(tic_tac_toe_board)
# print check_win(tic_tac_toe_board)
# tic_tac_toe_board = [["@","+","@"],["+","@","@"],["+","@","+"]]
# print_board(tic_tac_toe_board)
# print check_win(tic_tac_toe_board)
