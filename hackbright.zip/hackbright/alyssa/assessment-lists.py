
"""List Assessment
Edit the functions until all of the doctests pass when
you run this file.
"""


def print_indices(items):
    """Print each item in the list, followed by its index. Do this without
    using a "counting variable" --- that is, don't do something like this::
        count = 0
        for item in list:
            print count
            count = count + 1
    Output should look like this::
        >>> print_indices(["Toyota", "Jeep", "Volvo"])
        Toyota 0
        Jeep 1
        Volvo 2
        >>> print_indices(["Toyota", "Jeep", "Toyota", "Volvo"])
        Toyota 0
        Jeep 1
        Toyota 2
        Volvo 3

    """

    # Iterate index
    # Print value and index

    for index in range(len(items)):
        print items[index] + " " + str(index)

    # Could try list comprehensions here ^^
        #Can't use here since we are printing??


def words_in_common(words1, words2):
    """Find words in common.
    Given 2 lists of words, return the words that are in common
    between the two, sorted alphabetically.
    **NOTE**: for this problem, you're welcome to use any of the
    Python data structures you've been introduced to (not just
    lists).
    For example::
        >>> words_in_common(
        ...    ["Python", "Ruby", "R", "C++", "Haskell"],
        ...    ["Lizard", "Turtle", "Python"]
        ...    )
        ['Python']

    The returned list should not have any duplicates::
        >>> words_in_common(
        ...    ["cheese", "bagel", "cake", "cheese"],
        ...    ["hummus", "cheese", "beets", "kale", "bagel", "cake"]
        ... )
        ['bagel', 'cake', 'cheese']

    If there are no words in common, return an empty list::
        >>> words_in_common(
        ... ["lamb", "chili", "cheese"],
        ... ["cake", "ice cream"]
        ... )
        []

    If a duplicate exists in the original lists, the result will
    contain the value only once::
        >>> words_in_common(
        ...    ["Python", "Ruby", "R", "C++", "Haskell"],
        ...    ["Lizard", "Turtle", "Python", "Python"]
        ...    )
        ['Python']
    """

    # OPTION 1: Using list iteration
        # May want to use SET here to remove duplicates
        # Make new list
        # Iterate over list1, iterate over list2 (nested loops)

    common_words = []
    for word_in_1 in words1:
        for word_in_2 in words2:
            if word_in_1 == word_in_2:
                common_words.append(word_in_1)

    common_words_set = set(common_words)

    uniq_common_words = sorted(list(common_words_set))
    return uniq_common_words

    # OPTION 2: Use transform into dictionary -- easier to find keys?
        # Except what would be the keys vs values...

    # OPTION 3: Transform into sets and use set math (intersection) to get overlaps


def every_other_item(items):
    """Return every other item in `items`, starting at first item.
    For example::
       >>> every_other_item(['a', 'b', 'c', 'd', 'e', 'f'])
       ['a', 'c', 'e']
       >>> every_other_item(["pickle", "pickle", "juice", "pickle", "juice", "pop"])
       ['pickle', 'juice', 'juice']
       >>> every_other_item(
       ...   ["you", "z", "are", "z", "good", "z", "at", "x", "code"]
       ... )
       ['you', 'are', 'good', 'at', 'code']
    """

    # Use for loop, range with step - every other item

    every_other_item_list = []

    for index in range(0, len(items), 2):
       every_other_item_list.append(items[index])
    return every_other_item_list

    # Could try list comprehensions here ^^ (This doesn't seem to work...)
        # every_other_item_list = [every_other_item_list.append(items[index]) for index in range(0, len(items), 2)]
        # return every_other_item_list


def smallest_n_items(items, n):
    """Return the `n` smallest integers in list, in descending order.
    You can assume that `n` will be less than the length of the list.
    For example::
    >>> smallest_n_items([2, 6006, 700, 42, 6, 59], 3)
    [42, 6, 2]

    It should work when `n` is 0::
    >>> smallest_n_items([3, 4, 5], 0)
    []

    If there are duplicates in the list, they should be counted
    separately::
    >>> smallest_n_items([3, 1, 3, 2, 1, 1], 2)
    [1, 1]

    """

    # Sort list (small --> large)
        # OPTION 1: Pop * n
        # OPTION 2: Slice to get the n items in list
    # Reverse sort to get in descending order

    fwd_sorted_list = sorted(items)
    n_smallest = fwd_sorted_list[:n] # << OPTION 2 here

    #Option 1: With .pop() << pop returns int???
        # count = 1
        # while count < (len(items) - n):
        #     n_smallest = fwd_sorted_list.pop()
        #     count = count + 1

    n_smallest.reverse()
    return n_smallest


#####################################################################
# END OF ASSESSMENT: You can ignore everything below.

if __name__ == "__main__":
    import doctest

    result = doctest.testmod()
    if not result.failed:
        print "\nALL TESTS PASSED. GOOD WORK!\n"
