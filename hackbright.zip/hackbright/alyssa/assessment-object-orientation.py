"""
Part 1: Discussion

1. What are the three main design advantages that object orientation
   can provide? Explain each concept.

   Abstraction - Putting implementation into a "black box".
   Allows the user to not have to worry about how it all works and
   just be able to use the assocciated functions.

   Ecapsulation - Keeping realted functionality and qualities together.

   Polymorphism - The ability to inherit the functioanlity of other classes
   but also modify and customize them to fit the use in the current class.

2. What is a class?
    The type of a thing. Classes define the qualities and functionality that that type of
    a thing has and can do.

3. What is a method?

    Methods are functions defined on classes. Methods only work on instances a class.

4. What is an instance in object orientation?

    An instance is an example of the thing of the certain type defined by a class.

5. How is a class attribute different than an instance attribute?
   Give an example of when you might use each.

   Class attributes are defined on the class. They are qualities you want all of your instances of your class to have.
   For example, it would make sense that all objects of the Melon class would have a weight.
   Instance attibutes are defned on the object. They are qualities unique to each instance.
   For example, only watermelons have might have an attribute of has_pink_fruit.

"""


# Part 2: Road Class
# #############################################################################

# Create your Road class here
class Road (object):
    """ A road object """
    num_lanes = 2
    speed_limit = 25

# Instantiate Road objects here
road_1 = Road()
road_2 = Road()

road_1.num_lanes = 4
road_1.speed_limit = 60


# Part 3: Update Password
# #############################################################################
class User(object):
    """A user object."""

    def __init__(self, username, password):
        self.username = username
        self.password = password

    # write the update_password method here
    def update_password(self, password, new_password):
        """ Updates password if the user knows the previous password"""
        if password != self.password:
            print 'Invalid password'
        else:
            self.password = new_password


# Part 4: Build a Library
# #############################################################################
class Book(object):
    """A Book object."""

    def __init__(self, title, author):
        self.title = title
        self.author = author

# Create your Library class here


class Library(object):
    """A Library object"""
    def __init__(self):
        self.books = []

    def add_book(self, title, author):
        """ Adds book with title and author to libary """
        book = Book(title, author)
        self.books.append(book)

    def find_books_by_author(self, author):
        """ Finds and returns a list of books by a certain author """
        books_by_author = []
        for indx in range(len(self.books)):
            if self.books[indx].author == author:
                books_by_author.append(self.books[indx])
        return books_by_author

# For testing:
my_library = Library()
my_library.add_book('Harry Potter-Sorcerer Stone', 'J.K. Rowling')
my_library.add_book('Harry Potter-Chamber of Secrets', 'J.K. Rowling')
my_library.add_book('A Wrinkle in Time', 'Madeleine LEngle')

JK_books = my_library.find_books_by_author('J.K. Rowling')


# Part 5: Rectangles
# #############################################################################

class Rectangle(object):
    """A rectangle object."""

    def __init__(self, length, width):
        self.length = float(length)
        self.width = float(width)

    def calculate_area(self):
        """Return the rectangle's area (length * width)."""
        return self.length * self.width


# Create the Square class here
class Square(Rectangle):
    """A Square object"""

    def __init__(self, number):
        super(Square, self).__init__(number, number)

    def calculate_area(self):
        if self.length == self.width:
            return super(Square, self).calculate_area()
        else:
            print 'Invalid Square'
