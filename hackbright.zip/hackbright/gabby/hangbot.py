list_of_graphics = [
"""
 _                  _       _
| |_ ___ ___ ___   | |_ ___| |_
|   | .'|   | . |  | . | . |  _|
|_|_|__,|_|_|_  |  |___|___|_|
            |___|
_________________________________________
______________________________________|_|
| |  //                                |
| | //                                 |
| |//
| |
| |
| |                  ___
| |                 /() \
| |               _|_____|_
| |              | | === | |
| |              |_|  O  |_|
| |               ||  O  ||
| |               ||__*__||
| |              |~ \___/ ~|
| |              /=\ /=\ /=\
|________________[_]_[_]_[_]____________________________________________

""" ,
"""
 _                  _       _
| |_ ___ ___ ___   | |_ ___| |_
|   | .'|   | . |  | . | . |  _|
|_|_|__,|_|_|_  |  |___|___|_|
            |___|
_________________________________________
______________________________________|_|
| |  //                                |
| | //                                 |
| |//                                 /~\
| |                                  |o o)
| |                                   \=/
| |                  ___
| |                 /() \
| |               _|_____|_
| |              | | === | |
| |              |_|  O  |_|
| |               ||  O  ||
| |               ||__*__||
| |              |~ \___/ ~|
| |              /=\ /=\ /=\
| |              [_]_[_]_[_]
| |
""" ,
"""
 _                  _       _
| |_ ___ ___ ___   | |_ ___| |_
|   | .'|   | . |  | . | . |  _|
|_|_|__,|_|_|_  |  |___|___|_|
            |___|
_________________________________________
______________________________________|_|
| |  //                                |
| | //                                 |
| |//                                 /~\
| |                                  |o o)
| |                                  _\=/_
| |                  ___            |  _  |
| |                 /() \            |/.\|
| |               _|_____|_           \_/
| |              | | === | |         |\ /|
| |              |_|  O  |_|         \_ _/
| |               ||  O  ||
| |               ||__*__||
| |              |~ \___/ ~|
| |              /=\ /=\ /=\
| |              [_]_[_]_[_]
| |
""" ,
"""
 _                  _       _
| |_ ___ ___ ___   | |_ ___| |_
|   | .'|   | . |  | . | . |  _|
|_|_|__,|_|_|_  |  |___|___|_|
            |___|
_________________________________________
______________________________________|_|
| |  //                                |
| | //                                 |
| |//                                 /~\
| |                                  |o o)
| |                                  _\=/_
| |                  ___        #   /  _  |
| |                 /() \        \\//|/.\|
| |               _|_____|_       \/  \_/
| |              | | === | |         |\ /|
| |              |_|  O  |_|         \_ _/
| |               ||  O  ||
| |               ||__*__||
| |              |~ \___/ ~|
| |              [_]_[_]_[_]
| |
""" ,
"""
 _                  _       _
| |_ ___ ___ ___   | |_ ___| |_
|   | .'|   | . |  | . | . |  _|
|_|_|__,|_|_|_  |  |___|___|_|
            |___|
_________________________________________
______________________________________|_|
| |  //                                |
| | //                                 |
| |//                                 /~\
| |                                  |o o)
| |                                  _\=/_
| |                  ___        #   /  _  \   #
| |                 /() \        \\//|/.\|\\//
| |               _|_____|_       \/  \_/  \/
| |              | | === | |         |\ /|
| |              |_|  O  |_|         \_ _/
| |               ||  O  ||
| |               ||__*__||
| |              |~ \___/ ~|
| |              /=\ /=\ /=\
| |              [_]_[_]_[_]
| |
""" ,
"""
 _                  _       _
| |_ ___ ___ ___   | |_ ___| |_
|   | .'|   | . |  | . | . |  _|
|_|_|__,|_|_|_  |  |___|___|_|
            |___|
_________________________________________
______________________________________|_|
| |  //                                |
| | //                                 |
| |//                                 /~\
| |                                  |o o)
| |                                  _\=/_
| |                  ___        #   /  _  \   #
| |                 /() \        \\//|/.\|\\//
| |               _|_____|_       \/  \_/  \/
| |              | | === | |         |\ /|
| |              |_|  O  |_|         \_ _/
| |               ||  O  ||          | |
| |               ||__*__||          | |
| |              |~ \___/ ~|         []|
| |              /=\ /=\ /=\         | |
| |              [_]_[_]_[_]         /_]
| |
""" ,
"""
 _                  _       _
| |_ ___ ___ ___   | |_ ___| |_
|   | .'|   | . |  | . | . |  _|
|_|_|__,|_|_|_  |  |___|___|_|
            |___|
_________________________________________
______________________________________|_|
| |  //                                |
| | //                                 |
| |//                                 /~\
| |                                  |o o)      We're doomed!
| |                                  _\=/_
| |                  ___        #   /  _  \   #
| |                 /() \        \\//|/.\|\\//
| |               _|_____|_       \/  \_/  \/
| |              | | === | |         |\ /|
| |              |_|  O  |_|         \_ _/
| |               ||  O  ||          | | |
| |               ||__*__||          | | |
| |              |~ \___/ ~|         []|[]
| |              /=\ /=\ /=\         | | |
| |              [_]_[_]_[_]        /_]_[_\
| |
"""]


"""Final - Hangbot Project"""

"""A word will be chosen at random from a list
(CS vocabulary words) and the player must
guess the words before running out of guesses\n"""


from random import randint                                                      # built-in package needed to generate a random integer (https://stackoverflow.com/questions/3996904/generate-random-integers-between-0-and-9)

# welcome player and pring greeting with instructions
print "\n\tWelcome to Hangbot!\n"
print "\nInstructions:   A word will be chosen at random from a list,\n\t\tit's your job to guess the words before\n\t\trunning out of guesses-- Good luck!"

# remove duplicates
def remove_duplicates(list_with_dupes):                                         # This is a user defined funtion built to remove duplicates(one argument: list_with_dupes)
    # append duplicate letters in new list
    output_list = []                                                            # this is a new list called output_list where we can append the duplicat letters
    for x in list_with_dupes:                                                   # x = input
        if x in output_list:
            continue
        # append x to new list
        else:
            output_list.append(x)
    # the function - generate output and returns output
    return output_list

# line of seperation
line = "---------------------------------------------------------"

# Ask if user wants to play y/n
answer = raw_input("\nWould you like to play? Enter y/n: ").lower()

if answer == "y":
    name = raw_input("\nWhat is your name? ").capitalize()
    print line
    print "\n\tGreat {}! Let's play.\n".format(name)
    playing = True
elif answer == "n":
    print line
    print "No worries, bot you later.\n"
    playing = False
else:
    print "not a valid option - good-bye!"

# if playing is True loop
if playing == True:                                                             # Set up the word before the guessing loop (if playing is False it will skip this if statement)
    # chose a random word from list
    word_bank = ["dictionary", "nesting", "functions", "files", "variables",
    "operators", "lists", "conditionals", "tuples", "loops"]
    # pick a random int from the list of words
    random_index = randint(0, len(word_bank)-1)                                 # next we need to grab a random number to use as our list index to pick a random word
    # assign random word to a variable
    word = word_bank[random_index]                                              # needs the -1 for the maximum value (avoid error: list index out of range)
    # hide the initial word
    hidden_word = "_ " * len(word)
    # tell the user how many letters the word has
    print "\nYour word has {} letters \n".format(len(word))
    # display chosen word
    print hidden_word

# empty list for letters guessed
letters_guessed = []
# keep track of missed guesses                                                  # Important information you might want to store [hidden_word, letters_guessed, missed/wrong guesses, available letters, total guesses]
missed_guesses = 0
# keep track of total guesses
total_guesses = 7
#total_guesses = len(list_of_graphics)                                          # grahpics for game

# while playing loop for guessing interation
while playing:                                                                  # this is the guessing loop. It will iterate until the guesses have run out.
    user_letter = raw_input("Please guess a letter: ").lower()                  # check to see if they have already guessed this letter and restart loop if they have
    if user_letter in letters_guessed:                                          # is user letter in letters_guessed -f so print message "Oops. You already guessed that letter - try again"
        print line
        print "\n\tOops. You already guessed that letter - try again!\n"
    elif user_letter in word:                                                   # step 2 post-guess: interact with the user, set match variable. Determines whether or not they lose a turn.
        match = True
        print line
        print "\n\tGreat job, you got it right.\n"
    else:                                                                       # if letter wasn't guessed set match to false, increment missed guesses counter
        match = False
        missed_guesses += 1
        print line
        print "\n\tOops, try again!\n"

    # append user letter to letters guessed list, keep track of letters to unveil
    letters_guessed.append(user_letter)

    # reset word based on guess, build the hidden word
    hidden_word = ""                                                            # step 1 post-guess: build the hidden word once you have the latest guess
    for letter in word:                                                         # check to see if each letter was guessed, and reveal if guessed
        if letter in letters_guessed:                                           # reveal because it was guessed
            hidden_word = hidden_word + letter + " "                            # display correct guesses
        # keep masked if word has not been guessed
        else:                                                                       # else add masked "_" version
            hidden_word = hidden_word + "_ "                                        # keep masked because it wasnt guessed

    # print list_of_graphics[missed_guesses]
    print hidden_word                                                                   # show the hidden version of the word
    print "\nLetters guessed:\n\t" + str(remove_duplicates(letters_guessed))            # error: change an int to a string - and implement the function:remove_duplicate(with the parameters of letterers_guessed)
    print "\nYou have {} guesses left.\n".format(str(total_guesses - missed_guesses))   # tell the user how many guesses they have left

    # check to see if user guessed word                                                                                     # Step 3, determine if the game is still going
    if missed_guesses >= 7:                                                             # checking if missed guesses is 7, so I can put the boolian to False and exit the while loop.
        playing = False
        # out of guesses
        print "\nSorry you\'re out of guesses. The word is '{}'".format(word)
        print "\n\t  GAME OVER\n"
    # user guesses word
    elif "_" not in hidden_word:                                                # check to see if you won
        playing = False
        print "\nCongratulations! You guessed the word!!!\n"                    # show the hidden version of the word
