"""
Part 1: Discussion

1. What are the three main design advantages that object orientation
   can provide? Explain each concept.

Abstraction
    Hiding details we donot need, this is achieved through encapsulation.
    the internal representation and details are not visible and can be gotten
    only by special get() methods

Encapsulation
    Keeping everything together, each object is self-contained,
    each method does its own thing, i.e. it allows class to change its
    implementation without affecting other parts of the code

Polymorphism
    Interchangeability of components
    in a sub-class we can use the method from the superclass and still over-ride
    or changing the way how these m


2. What is a class?
    Class is a user-defined data type, that can be used to build and group together related
    data and functions. These functions are called methods and they can act upon
    the data.
    classes also have attributes, which are variables of the class.


3. What is a method?
    Method is a function defined in the class, that acts upon the data in the
    class instance.
    - it has similar syntax like the functions in python.
    - the first parameter in the definition of a method has to be a reference
    "self" to the instance of the class


4. What is an instance in object orientation?

    Individual occurrence of a class is instance, i.e. instance of calling a
    class creates an instance of that class.


    Class Students():
    Bhavana = Students()

    This is making an instance of a class or instatiating the class Students.



5. How is a class attribute different than an instance attribute?
   Give an example of when you might use each.

   Instance attributes relate to the particular instance, whereas class attributes
   influence or are relevant to all the instances. However, a particular class
   attribute can be overwritten with instance attribute.

   Instance attributes are used to set properties for a particular instance of
   a class

   Class attributes can sometimes be placeholders or can mark out what will be
   entered in the instances.

   Class attributes are used to set properties for all the instances for that class
   , however, the class attributes can be overwritten by instance attribute.

   class Animal(object):
    species = "dog"

    species is a class attribute



    fido = Animal()
    fido.name = 'Fido'

    name is an instance attribute


"""


# Part 2: Road Class
# #############################################################################

# Create your Road class here
class Road(object):
    """Creates a Road class"""

    num_lanes = 2
    speed_limit = 25

# Instantiate class Road objects
road_1 = Road()
road_2 = Road()

# Update road_1 attributes
road_1.num_lanes = 4
road_1.speed_limit = 60

# Part 3: Update Password
# #############################################################################
class User(object):
    """A user object."""

    def __init__(self, username, password):
        self.username = username
        self.password = password


    # write the update_password method here
    def update_password(self, old_password, new_password):
        """ Updates old password
            """

        if self.password == old_password:
            self.password = new_password
        else:
            print "Invalid password"

# Part 4: Build a Library
# #############################################################################
class Book(object):
    """A Book object."""

    def __init__(self, title, author):
        self.title = title
        self.author = author

# Create your Library class here
class Library(object):
    """ A library object"""

    def __init__(self):
        self.books = []

    def add_book(self, title, author):
        """ Adds books to the library"""

        self.lib_book = Book(title, author)
        self.books.append(self.lib_book)

    def find_books_by_author(self, author):
        """ FInds books in the library by author"""

        book_name = []
        for book in self.books:
            if book.author == author:
                book_name.append(book)
        return book_name



# Part 5: Rectangles
# #############################################################################

class Rectangle(object):
    """A rectangle object."""

    def __init__(self, length, width):
        self.length = float(length)
        self.width = float(width)

    def calculate_area(self):
        """Return the rectangle's area (length * width)."""
        return self.length * self.width


# Create the Square class here

class Square(Rectangle):

    def __init__(self, length):
        super(Square, self).__init__(length, width=length)

    '''def calculate_area_square(self):
        if self.width == self.length:
            area = super(Square,self).calculate_area()
            return area
        else:
            print "Invalid square"
            return None'''
    def calculate_area(self):
        """ Return the square's area"""

        if self.width == self.length:
            return self.length * self.width
        else:
            print "Invalid square"
            return None
