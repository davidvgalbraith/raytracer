class Animal(object):
    def __init__(self, name):
        self.name = name
    def speak(self):
        print("my name is", self.name)

class Dog(Animal):
    def __init__(self, name, age):
        self.age = age
        return super(Dog, self).__init__(name)
    def speak(self):
        print "Hey this dog speak"
        super(Dog, self).speak()

fido = Dog("fido", 37)
fido.speak()
