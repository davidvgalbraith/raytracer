from random import randint


def print_info():
    """Prints the greeting and instructions for player"""

    welcome = """
    Welcome to the game of 21!

    you will be given 2 numbers in the range of 0 to 10.
    """

    print welcome

#------------------------------------2-----#
def gen_num():

    random_integer = randint(0, 10)
    player = raw_input("Do you want another number?")
    total_num = random_integer + player
    print "Your total is " + total_num

    if not player.isdigit():
        print "Please guess an integer."

def user_yes():
    # while loop:
    # ask user if they want another number
        # if user's answer is yes:
            # generate another random number
            # display the new number to the user
            # check if they have reached 21
                # if they are over 21:
                    # print some other message about busting
                # elif they are equal to 21:
                    # tell them they won
                # else:
                    # continue, which brings us to our next loop iteration

    while player == True:
        player = raw_input("Do you want another number?")


        if player == 'yes':
            print gen_num()
            print "Your total is {}".format(player)

        elif player <= 21: #(check if they have reached 21)#### correctly written
            print "Your total is {}".format(player)

        elif player > 21:
            print " Your total is {} and you have busted :-(".format(player)

        elif player == 21:
            print " Your total is {} and you won!!! :-)".format(player)

        else:
            continue
        #can I split the loop into 2 functions????##############

def user_no(): # write this function#
# elif user's answer is no:
            # reveal the total of their current cards
            # check if they have reached 21
                # if they are over 21:
                    # print message about busting
                    # break
                # elif they are at 21:
                    # print you won
                    # break
                # else:
                    # print better luck next time
                    # break
    while player == 'no':
        print "Your total is {}".format(player)

        if player > 21:
            print "Your total is {} and you have busted :-(".format(player)
            break
        elif player == 21:
            print "Your total is {} and  you won :-)".format(player)
            break


def play_game():
    print_info()
    gen_num()

    if player == "Yes":
        user_yes()
    else:
        user_no()


play_game()
